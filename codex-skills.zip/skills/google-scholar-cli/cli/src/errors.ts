/** Stable exit codes for scripts; browser/session recovery uses Surf. */
export const EXIT = { OK: 0, UNAVAILABLE: 69, NOPERM: 77, TEMPFAIL: 75 } as const;

export class AuthError extends Error {
  constructor(message: string, readonly exitCode: number) {
    super(message);
    this.name = "AuthError";
  }
}

export function browserUnreachable(): AuthError {
  return new AuthError(
    "Surf could not access Chrome. Run 'surf doctor', check the connected Chrome profile, then retry 'scholar auth'.",
    EXIT.UNAVAILABLE,
  );
}

export function notSignedIn(service: string): AuthError {
  return new AuthError(
    `Not signed in to ${service}. Sign in in Surf's connected Chrome, then run 'scholar auth'.`,
    EXIT.NOPERM,
  );
}

export function blocked(service: string): AuthError {
  return new AuthError(
    `${service} returned a CAPTCHA or rate limit. Resolve it in Surf's connected Chrome, then run 'scholar auth'. Do not retry in a loop.`,
    EXIT.TEMPFAIL,
  );
}

export function exitCodeFor(err: unknown): number {
  return err instanceof AuthError ? err.exitCode : 1;
}
