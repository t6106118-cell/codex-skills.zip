/**
 * BibTeX utilities for Google Scholar citation extraction.
 *
 * Parses the Scholar citation popup HTML to extract the BibTeX download URL.
 */

/**
 * Extract the BibTeX URL from a Google Scholar citation popup HTML.
 *
 * The citation popup contains anchor tags with class "gs_citi" for each
 * format (MLA, APA, Chicago, Harvard, Vancouver, BibTeX, EndNote, RefMan, RefWorks).
 * The BibTeX link has the text "BibTeX".
 *
 * @returns The BibTeX URL, or null if not found.
 */
export function extractBibtexUrl(html: string): string | null {
  if (!html) return null;

  // Match anchor tags with class containing "gs_citi" and text "BibTeX"
  const match = html.match(
    /<a[^>]*class="gs_citi"[^>]*href="([^"]*)"[^>]*>\s*BibTeX\s*<\/a>/,
  );

  return match ? match[1].replace(/&amp;/g, "&") : null;
}
