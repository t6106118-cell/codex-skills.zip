import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { deriveIdentity, saveIdentity, type BrowserIdentity, type UaBrand } from "./identity.js";
import { resolveAllCookies, saveAllCookies, saveCookies, type BrowserCookie, type Cookies } from "./auth.js";
import { AuthError, blocked, browserUnreachable, EXIT, notSignedIn } from "./errors.js";

const exec = promisify(execFile);
const SESSION = "scholar-auth";
const GOOGLE_NAMES = new Set([
  "SID", "SSID", "HSID", "SAPISID", "APISID", "SIDCC", "NID", "1P_JAR",
]);

export function isGoogleDomain(domain: string): boolean {
  const host = domain.replace(/^\./, "").toLowerCase();
  return host === "google.com" || host.endsWith(".google.com");
}

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function invalidData(): AuthError {
  return new AuthError("Surf returned invalid browser data. Check 'surf doctor' and the installed Surf version.", EXIT.UNAVAILABLE);
}

/** Validate the external boundary without ever including private values in errors. */
export function parseSurfCookies(value: unknown): BrowserCookie[] {
  if (!Array.isArray(value)) throw invalidData();
  return value.map((c: unknown) => {
    if (!record(c) || typeof c.name !== "string" || typeof c.value !== "string" ||
      typeof c.domain !== "string" || typeof c.path !== "string" ||
      typeof c.secure !== "boolean" || typeof c.hostOnly !== "boolean") throw invalidData();
    const host = c.domain.replace(/^\./, "").toLowerCase();
    return { name: c.name, value: c.value, domain: c.hostOnly ? host : `.${host}`, path: c.path, secure: c.secure };
  }).filter(c => isGoogleDomain(c.domain));
}

async function surf(args: string[]): Promise<unknown> {
  // Metadata commands take a positional session name; prevent an inherited target
  // from overriding it. Data commands explicitly target the owned auth tab.
  const { SURF_SESSION: _ignored, ...env } = process.env;
  let stdout: string;
  try {
    ({ stdout } = await exec("surf", [...args, "--json"], {
      timeout: 30_000, maxBuffer: 2 * 1024 * 1024, env,
    }));
  } catch {
    // Child-process errors contain stdout/stderr; never relay cookie payloads.
    throw browserUnreachable();
  }
  let envelope: unknown;
  try { envelope = JSON.parse(stdout); } catch { throw invalidData(); }
  if (!record(envelope)) throw invalidData();
  if (args[0] === "session.ensure" && record(envelope.session)) return envelope.session;
  if (!("result" in envelope)) throw invalidData();
  return envelope.result;
}

export interface SurfSession {
  googleCookies: Cookies;
  allBrowserCookies: BrowserCookie[];
  identity: BrowserIdentity;
}

/** Refresh from the user's working Chrome profile through Surf, not a CDP profile. */
export async function extractSurfSession(): Promise<SurfSession> {
  await surf(["session.ensure", SESSION, "about:blank", "--tab"]);
  await surf(["--session", SESSION, "navigate", "https://scholar.google.com/"]);
  const page = await surf(["--session", SESSION, "js",
    "({origin:location.origin,blocked:/unusual traffic|automated queries/i.test(document.body.innerText) || !!document.querySelector('#gs_captcha'),userAgent:navigator.userAgent,platform:navigator.userAgentData?.platform,brands:navigator.userAgentData?.brands})"]);
  if (!record(page) || typeof page.origin !== "string" || typeof page.userAgent !== "string" || typeof page.blocked !== "boolean") throw invalidData();
  if (page.blocked || page.origin === "https://www.google.com" || page.origin === "https://google.com") throw blocked("Google Scholar");
  if (page.origin !== "https://scholar.google.com") throw notSignedIn("Google Scholar");
  const brands = page.brands;
  if (brands !== undefined && (!Array.isArray(brands) || !brands.every(b => record(b) && typeof b.brand === "string" && typeof b.version === "string"))) throw invalidData();
  if (page.platform !== undefined && typeof page.platform !== "string") throw invalidData();
  const allBrowserCookies = parseSurfCookies(await surf(["--session", SESSION, "cookie.list"]));
  const googleCookies: Cookies = {};
  for (const c of allBrowserCookies) {
    if (GOOGLE_NAMES.has(c.name) || c.name.startsWith("__Secure-")) googleCookies[c.name] = c.value;
  }
  if (Object.keys(googleCookies).length === 0) throw notSignedIn("Google Scholar");
  return {
    googleCookies, allBrowserCookies,
    identity: deriveIdentity(page.userAgent, { platform: page.platform as string | undefined, brands: brands as UaBrand[] | undefined }),
  };
}

/** Keep existing publisher/proxy records; Surf cookie.list covers this tab's host. */
export function saveSurfSession(session: SurfSession): void {
  const otherDomains = resolveAllCookies().filter(c => !isGoogleDomain(c.domain));
  saveCookies(session.googleCookies);
  saveAllCookies([...otherDomains, ...session.allBrowserCookies]);
  saveIdentity(session.identity);
}
