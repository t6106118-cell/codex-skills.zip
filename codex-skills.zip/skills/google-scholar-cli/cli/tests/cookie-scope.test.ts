import { afterAll, afterEach, describe, expect, it } from "bun:test";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { cookiesForUrl, type BrowserCookie } from "../src/auth.js";
import { downloadPdf } from "../src/api/scholar.js";

const google: BrowserCookie = {
  name: "SID", value: "SYNTHETIC-TEST-ONLY", domain: ".google.com", path: "/", secure: true,
};
const publisher: BrowserCookie = {
  name: "publisher-session", value: "SYNTHETIC-PUBLISHER", domain: "publisher.test", path: "/papers", secure: true,
};

describe("download cookie scope", () => {
  const originalFetch = globalThis.fetch;
  const scratch = mkdtempSync(join(tmpdir(), "scholar-cookie-scope-"));

  afterAll(() => rmSync(scratch, { recursive: true, force: true }));

  afterEach(() => {
    globalThis.fetch = originalFetch;
    rmSync(join(scratch, "paper.pdf"), { force: true });
  });

  function recordRequests(redirects: string[] = []) {
    const seen: Array<{ url: string; cookie: string }> = [];
    globalThis.fetch = (async (input, init) => {
      const url = input instanceof Request ? input.url : String(input);
      seen.push({ url, cookie: new Headers(init?.headers).get("Cookie") ?? "" });
      const location = redirects[seen.length - 1];
      return location
        ? new Response(null, { status: 302, headers: { Location: location } })
        : new Response("%PDF-1.4\n%%EOF\n", { headers: { "Content-Type": "application/pdf" } });
    }) as typeof fetch;
    return seen;
  }

  it("never sends flat Google cookies to an unrelated download host", async () => {
    for (const all of [undefined, [], [google]]) {
      const seen = recordRequests();
      await downloadPdf("https://unrelated.test/paper.pdf", join(scratch, "paper.pdf"), { SID: google.value }, all);
      expect(seen[0].cookie).toBe("");
    }
  });

  it("keeps the Google-only snapshot usable on HTTPS Scholar", async () => {
    const seen = recordRequests();
    await downloadPdf("https://scholar.google.com/paper", join(scratch, "paper.pdf"), { SID: google.value });
    expect(seen[0].cookie).toBe(`SID=${google.value}`);
  });

  it("recomputes cookie scope at every cross-host redirect", async () => {
    const seen = recordRequests(["https://publisher.test/papers/paper.pdf", "https://unrelated.test/paper.pdf"]);
    await downloadPdf("https://scholar.google.com/paper", join(scratch, "paper.pdf"), { SID: google.value }, [google, publisher]);
    expect(seen.map((request) => request.cookie)).toEqual([
      `SID=${google.value}`, "publisher-session=SYNTHETIC-PUBLISHER", "",
    ]);
  });

  it("does not send secure cookies or the Google fallback over HTTP", async () => {
    const seen = recordRequests(["http://scholar.google.com/paper"]);
    await downloadPdf("http://publisher.test/papers/paper.pdf", join(scratch, "paper.pdf"), { SID: google.value }, [google, publisher]);
    expect(seen.map((request) => request.cookie)).toEqual(["", ""]);
  });
});

describe("browser cookie boundaries", () => {
  it("keeps host-only cookies off subdomains", () => {
    expect(cookiesForUrl([publisher], "https://sub.publisher.test/papers/paper.pdf")).toBe("");
    expect(cookiesForUrl([{ ...publisher, domain: ".publisher.test" }], "https://sub.publisher.test/papers/paper.pdf")).toBe("publisher-session=SYNTHETIC-PUBLISHER");
  });

  it("matches cookie paths at a slash boundary", () => {
    expect(cookiesForUrl([publisher], "https://publisher.test/papers/paper.pdf")).toBe("publisher-session=SYNTHETIC-PUBLISHER");
    expect(cookiesForUrl([publisher], "https://publisher.test/papers")).toBe("publisher-session=SYNTHETIC-PUBLISHER");
    expect(cookiesForUrl([publisher], "https://publisher.test/papers-private/paper.pdf")).toBe("");
    expect(cookiesForUrl([publisher], "https://publisher.test/other/paper.pdf")).toBe("");
  });

  it("keeps secure cookies off HTTP URLs", () => {
    expect(cookiesForUrl([publisher], "http://publisher.test/papers/paper.pdf")).toBe("");
  });
});
