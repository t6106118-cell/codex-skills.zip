import { afterAll, expect, mock, test } from "bun:test";
import * as realAuth from "../src/auth.js";

// Keep the real cookie matcher, replacing only the saved session boundary.
const auth = {
  ...realAuth,
  resolveCookies: () => ({ SID: "SYNTHETIC-GOOGLE" }),
  resolveAllCookies: () => [{
    name: "GSP", value: "SYNTHETIC-SCHOLAR", domain: "scholar.google.com",
    path: "/scholar", secure: true,
  }],
};
mock.module("../src/auth.js", () => auth);
const { cmdLookup } = await import("../src/commands/lookup.js");
const originalFetch = globalThis.fetch;
afterAll(() => { globalThis.fetch = originalFetch; });

test("lookup includes a cookie scoped to its actual /scholar request path", async () => {
  let sentCookie = "";
  globalThis.fetch = (async (_input, init) => {
    sentCookie = new Headers(init?.headers).get("Cookie") ?? "";
    // Stop after request construction; parsing and real network are unrelated.
    return new Response("unavailable", { status: 503 });
  }) as typeof fetch;
  const status = await cmdLookup(["synthetic query"], {
    json: true, help: false, bibtex: false, download: false,
  });
  expect(status).toBe(1);
  expect(sentCookie).toContain("GSP=SYNTHETIC-SCHOLAR");
});
