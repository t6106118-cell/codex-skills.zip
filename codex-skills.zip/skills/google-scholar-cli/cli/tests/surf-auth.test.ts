import { expect, it } from "bun:test";
import { parseSurfCookies, isGoogleDomain } from "../src/surf.js";
import { cookiesForUrl } from "../src/auth.js";
import { institutionalIdFromHtml } from "../src/commands/auth.js";

it("preserves host-only and domain scope and excludes unrelated browser cookies", () => {
  const base = { name: "SID", value: "synthetic", path: "/", secure: true };
  const cookies = parseSurfCookies([
    { ...base, domain: ".google.com", hostOnly: false },
    { ...base, name: "local", domain: "scholar.google.com", hostOnly: true },
    { ...base, domain: "mail.example.org", hostOnly: true },
  ]);
  expect(cookies).toHaveLength(2);
  expect(cookiesForUrl(cookies, "https://other.google.com/")).toBe("SID=synthetic");
  expect(cookiesForUrl(cookies, "https://scholar.google.com/")).toBe("SID=synthetic; local=synthetic");
  expect(cookiesForUrl(cookies, "https://google.com.example.org/")).toBe("");
  expect(cookiesForUrl(cookies, "http://scholar.google.com/")).toBe("");
  expect(isGoogleDomain("evilgoogle.com")).toBe(false);
});

it("rejects malformed Surf data without echoing private payloads", () => {
  expect(() => parseSurfCookies({ private: "synthetic-secret" })).toThrow("invalid browser data");
  expect(() => parseSurfCookies([{ name: "synthetic-secret" }])).toThrow("invalid browser data");
});

it("finds selected library-link IDs, not other checked controls or unselected libraries", () => {
  expect(institutionalIdFromHtml('<input value="123456789012" checked name="inst">')).toBe("123456789012");
  expect(institutionalIdFromHtml("<input checked='checked' name='inst' value='1234'>")).toBe("1234");
  expect(institutionalIdFromHtml('<input name="other" checked value="123456789012"><input name="inst" value="4321"><input name="inst" checked value="1">')).toBeNull();
});
