import { describe, it, expect } from "bun:test";

const REPO_ROOT = new URL("..", import.meta.url).pathname;

// ============================================================
// Unit tests for cookiesForUrl
// ============================================================
describe("cookiesForUrl", () => {
  it("matches .google.com cookies to scholar.google.com", async () => {
    const { cookiesForUrl } = await import("../src/auth.js");
    const cookies = [
      {
        name: "SID",
        value: "abc123",
        domain: ".google.com",
        path: "/",
        secure: true,
      },
    ];
    const result = cookiesForUrl(cookies, "https://scholar.google.com/search");
    expect(result).toBe("SID=abc123");
  });

  it("matches libkey.io cookies to libkey.io", async () => {
    const { cookiesForUrl } = await import("../src/auth.js");
    const cookies = [
      {
        name: "session",
        value: "xyz789",
        domain: "libkey.io",
        path: "/",
        secure: true,
      },
    ];
    const result = cookiesForUrl(cookies, "https://libkey.io/libraries/1234");
    expect(result).toBe("session=xyz789");
  });

  it("does NOT match .google.com cookies to libkey.io", async () => {
    const { cookiesForUrl } = await import("../src/auth.js");
    const cookies = [
      {
        name: "SID",
        value: "abc123",
        domain: ".google.com",
        path: "/",
        secure: true,
      },
    ];
    const result = cookiesForUrl(cookies, "https://libkey.io/something");
    expect(result).toBe("");
  });

  it("handles cookies with leading dot and without", async () => {
    const { cookiesForUrl } = await import("../src/auth.js");
    const cookies = [
      {
        name: "a",
        value: "1",
        domain: ".example.com",
        path: "/",
        secure: false,
      },
      {
        name: "b",
        value: "2",
        domain: "example.com",
        path: "/",
        secure: false,
      },
    ];
    const result = cookiesForUrl(cookies, "https://example.com/page");
    expect(result).toContain("a=1");
    expect(result).toContain("b=2");
  });

  it("matches subdomain with leading-dot domain cookie", async () => {
    const { cookiesForUrl } = await import("../src/auth.js");
    const cookies = [
      {
        name: "token",
        value: "abc",
        domain: ".university.edu",
        path: "/",
        secure: false,
      },
    ];
    const result = cookiesForUrl(
      cookies,
      "https://proxy.university.edu/login",
    );
    expect(result).toBe("token=abc");
  });

  it("returns empty string when no cookies match", async () => {
    const { cookiesForUrl } = await import("../src/auth.js");
    const cookies = [
      {
        name: "SID",
        value: "abc123",
        domain: ".google.com",
        path: "/",
        secure: true,
      },
    ];
    const result = cookiesForUrl(cookies, "https://unrelated.org/page");
    expect(result).toBe("");
  });

  it("formats multiple matching cookies correctly", async () => {
    const { cookiesForUrl } = await import("../src/auth.js");
    const cookies = [
      {
        name: "SID",
        value: "abc",
        domain: ".google.com",
        path: "/",
        secure: true,
      },
      {
        name: "HSID",
        value: "def",
        domain: ".google.com",
        path: "/",
        secure: true,
      },
      {
        name: "other",
        value: "xyz",
        domain: ".libkey.io",
        path: "/",
        secure: true,
      },
    ];
    const result = cookiesForUrl(
      cookies,
      "https://scholar.google.com/search",
    );
    expect(result).toBe("SID=abc; HSID=def");
  });

  it("returns empty string for empty cookie array", async () => {
    const { cookiesForUrl } = await import("../src/auth.js");
    const result = cookiesForUrl([], "https://example.com");
    expect(result).toBe("");
  });
});

// ============================================================
// Unit tests for downloadPdf with allCookies (manual redirect following)
// ============================================================
describe("downloadPdf with allCookies", () => {
  it("downloadPdf accepts optional allCookies parameter", async () => {
    const { downloadPdf } = await import("../src/api/scholar.js");
    // Just verify the function signature accepts 4 params without error
    // We can't actually call it without a real server, but we verify the type
    expect(typeof downloadPdf).toBe("function");
    expect(downloadPdf.length).toBeGreaterThanOrEqual(3);
  });
});

// ============================================================
// CLI regression test
// ============================================================
describe("CLI auth regression", () => {
  it("scholar --help mentions auth command", async () => {
    const proc = Bun.spawn(
      ["bun", "run", "src/main.ts", "--help"],
      {
        cwd: REPO_ROOT,
        stdout: "pipe",
        stderr: "pipe",
      },
    );

    const stdout = await new Response(proc.stdout).text();
    const exitCode = await proc.exited;

    expect(exitCode).toBe(0);
    expect(stdout).toContain("auth");
  });
});

// ============================================================
// Config tests
// ============================================================
describe("BROWSER_COOKIES_FILE config", () => {
  it("BROWSER_COOKIES_FILE is defined and points to browser-cookies", async () => {
    const { BROWSER_COOKIES_FILE } = await import("../src/config.js");
    expect(BROWSER_COOKIES_FILE).toBeDefined();
    expect(BROWSER_COOKIES_FILE).toContain("browser-cookies");
    expect(BROWSER_COOKIES_FILE).toContain(".google-scholar");
  });
});
