import { describe, it, expect } from "bun:test";
import { parseFlags, parseLimit } from "../src/main.js";

describe("parseFlags", () => {
  it("parses --json as boolean flag", () => {
    const result = parseFlags(["--json"]);
    expect(result.flags.json).toBe(true);
    expect(result.args).toEqual([]);
  });

  it("parses --limit 3 as string value flag", () => {
    const result = parseFlags(["--limit", "3"]);
    expect(result.flags.limit).toBe("3");
    expect(result.args).toEqual([]);
  });

  it("parses --limit as a string value flag", () => {
    const result = parseFlags(["search", "q", "--limit", "2"]);
    expect(result.flags.limit).toBe("2");
    expect(result.args).toEqual(["search", "q"]);
  });

  it("parses positional args correctly", () => {
    const result = parseFlags(["search", "my query"]);
    expect(result.args).toEqual(["search", "my query"]);
    expect(result.flags).toEqual({});
  });

  it("handles -- separator", () => {
    const result = parseFlags(["--json", "--", "--not-a-flag", "value"]);
    expect(result.flags.json).toBe(true);
    expect(result.args).toEqual(["--not-a-flag", "value"]);
  });

  it("handles mixed flags and args", () => {
    const result = parseFlags(["search", "my query", "--json"]);
    expect(result.args).toEqual(["search", "my query"]);
    expect(result.flags.json).toBe(true);
  });

  it("handles unknown flags gracefully", () => {
    const result = parseFlags(["--unknown-flag", "--another"]);
    expect(result.flags["unknown-flag"]).toBe(true);
    expect(result.flags.another).toBe(true);
    expect(result.args).toEqual([]);
  });

  it("parses empty argv", () => {
    const result = parseFlags([]);
    expect(result.args).toEqual([]);
    expect(result.flags).toEqual({});
  });

  it("handles --interactive as boolean flag", () => {
    const result = parseFlags(["search", "--interactive"]);
    expect(result.flags.interactive).toBe(true);
    expect(result.args).toEqual(["search"]);
  });

  it("handles --help as boolean flag", () => {
    const result = parseFlags(["--help"]);
    expect(result.flags.help).toBe(true);
    expect(result.args).toEqual([]);
  });

  it("handles flag with value followed by boolean flag", () => {
    const result = parseFlags(["--limit", "3", "--json"]);
    expect(result.flags.limit).toBe("3");
    expect(result.flags.json).toBe(true);
    expect(result.args).toEqual([]);
  });

  it("treats flag value starting with -- as boolean", () => {
    // --limit followed by --json means port is boolean, json is boolean
    const result = parseFlags(["--limit", "--json"]);
    expect(result.flags.limit).toBe(true);
    expect(result.flags.json).toBe(true);
  });
});

describe("config exports", () => {
  it("exports CONFIG_DIR, COOKIES_FILE, API_BASE, SEARCH_PATH", async () => {
    const config = await import("../src/config.js");
    expect(config.CONFIG_DIR).toContain(".google-scholar");
    expect(config.COOKIES_FILE).toContain("cookies");
    expect(config.API_BASE).toBe("https://scholar.google.com");
    expect(config.SEARCH_PATH).toBe("/scholar_labs/search");
  });
});

describe("output exports", () => {
  it("exports printJson, printTable, printError", async () => {
    const output = await import("../src/output.js");
    expect(typeof output.printJson).toBe("function");
    expect(typeof output.printTable).toBe("function");
    expect(typeof output.printError).toBe("function");
  });
});

describe("parseLimit", () => {
  it("returns undefined when the flag is absent", () => {
    expect(parseLimit(undefined)).toBeUndefined();
  });

  it("parses a positive integer", () => {
    expect(parseLimit("2")).toBe(2);
    expect(parseLimit("10")).toBe(10);
  });

  it("rejects a bare --limit with no value", () => {
    expect(parseLimit(true)).toBeNull();
  });

  it("rejects zero, negatives, fractions and garbage", () => {
    expect(parseLimit("0")).toBeNull();
    expect(parseLimit("-1")).toBeNull();
    expect(parseLimit("2.5")).toBeNull();
    expect(parseLimit("abc")).toBeNull();
    expect(parseLimit("")).toBeNull();
  });
});
