# Google Scholar CLI with Surf authentication

This is the complete adapted source, not a patch that needs another clone.
It preserves the local Surf authentication, cookie-scope, BibTeX and journal-parser
changes. See [PROVENANCE.md](PROVENANCE.md) for the upstream source revision.

## Build

Install Bun 1.4.4, then run in this directory:

```bash
bun install --frozen-lockfile
bun run typecheck
bun run test
bun run build
./scholar --help
```

`bun.lock` locks the development dependencies. The build produces a standalone
`scholar` executable for the host platform. Bun is required to build, not to run
that executable. Linux x64 is the verified platform.

For global skill and executable installation, follow [../RUNTIME.md](../RUNTIME.md).

## Authenticate and use

Set up [Surf](https://github.com/nicobailon/surf-cli), its Chrome extension/native
host and a signed-in browser profile. Then:

```bash
surf doctor
./scholar auth
./scholar lookup '"Attention Is All You Need"' --limit 3 --json
./scholar search 'papers on attention mechanisms in neural networks' --limit 3 --json
./scholar lookup 'passive funds voting' --journal 'Journal of Corporation Law' --limit 3 --json
./scholar lookup '"Attention Is All You Need"' --limit 1 --bibtex > references.bib
./scholar cite <clusterId> --json
./scholar download 'https://arxiv.org/pdf/1706.03762' --output paper.pdf
```

The `clusterId` comes from search results and may be alphanumeric. Repeated
`--journal` flags combine with OR on classic `lookup`; Labs `search` rejects that
flag. `--bibtex --json` emits `{clusterId,bibtex}` records rather than search metadata.

Surf is used for local session refresh. Search, citation and download requests
then run through the CLI's own HTTP/parser implementation. Private cookie and
identity snapshots live in `~/.google-scholar`. Never commit them. A new machine
must authenticate independently; source code cannot preserve a usable login.

The default tests mock network calls and use temporary files for session writes.
They run each test file in its own process. Optional live journal tests require
`SCHOLAR_LIVE=1`; leave it unset for offline/default testing.

This tool uses unofficial Google interfaces and cannot guarantee uninterrupted
access. Paid institutional access is unverified. See the skill's
[RUNTIME.md](../RUNTIME.md) for remaining behavior limits.
