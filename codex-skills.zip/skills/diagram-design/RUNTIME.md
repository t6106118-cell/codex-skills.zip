# Diagram Design runtime provisioning

Copying this skill supplies its scripts and references but does not necessarily
install their runtimes. Python 3.10 or newer supports the standard-library
helpers. PNG export additionally needs Python Playwright and a compatible
headless Chromium; this does not require an MCP server.

For a fresh Linux account, one way to recreate the dedicated runtime is:

```bash
uv init --bare --no-workspace --name diagram-design-runtime "$HOME/.local/share/diagram-design"
uv add --project "$HOME/.local/share/diagram-design" 'playwright==1.64.1'
uv run --project "$HOME/.local/share/diagram-design" python -m playwright install --only-shell chromium
```

These commands expect `uv`, Python, and network access, and the first command
assumes the project is absent. Inspect an existing runtime before changing it;
do not overwrite local customizations. Playwright and its browser may also need
host libraries; use the [Playwright browser documentation](https://playwright.dev/python/docs/browsers)
for the target platform. Fedora support and browser artifacts can change, so
use the requested PNG export directly with
[`references/export.md`](references/export.md), and diagnose its actual error if the browser cannot launch.

Version 1.64.1 and the helper were tested on the recorded workstation. The
`uv` project and browser cache are outside this skill folder, so copying the
skill alone does not transfer them. Ordinary export and doctor workflows do
not automatically install or alter dependencies.
