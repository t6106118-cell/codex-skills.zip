---
name: create-verification-skill
description: Create a project-local Codex skill for repeatedly launching and exercising an application's real UI, CLI, or API. Use when the user requests a reusable project-specific app verification or control workflow, not for an ordinary one-off test.
license: MIT
---

# Create a verification skill

Create a small, project-specific workflow that lets a future agent exercise the requested application behavior and observe its result. Follow the user's scope and project instructions; creating a skill does not authorize external messages, destructive operations, production changes, or unrelated product fixes.

Read the installed skill-creator guidance before authoring the skill. Inspect only the relevant project instructions, code, and existing run, test, or browser tooling needed to establish the real workflow. Identify the surface, launch command and prerequisites, how to drive it, observable outcomes, and safe cleanup. Reuse established project tooling and Codex tools; do not assume Cursor, a specific browser, or a new harness. Prefer an existing running instance when appropriate and do not disrupt user sessions or data. If a prerequisite is unavailable, report it; do not fabricate commands or observations.

Place the generated skill in the project-local Codex skill location under `.agents/skills/<name>/`, unless the project has an established applicable convention or the user specifies a location. Make its frontmatter describe the application, scope, and when to use it. Include only useful, grounded instructions: prerequisites, launch and readiness where relevant, real commands or selectors to exercise the requested behavior, observable results, failure diagnosis, and cleanup of resources the agent started. Explain isolation where concurrent runs can interfere. Add reusable helpers or feature-specific references only when a concrete recurring need justifies them. Keep project data and any requested evidence intact.

A reusable workflow should be grounded in actual project behavior. When authorized and practical, exercise the generated instructions on a safe representative path and report what ran; if not run, identify it as unverified and state the obstacle. Follow the user's explicit verification constraints. Do not claim a test passed based on a health check or process startup alone. Summarize the generated skill, its scope, how to invoke it, and any limitations.
