---
name: project-continuity
description: Establish and maintain project-local instructions, current state, and selected durable knowledge so a fresh agent can resume substantial multi-step coding, research, analysis, or writing after an abrupt switch. Use at task entry, meaningful work boundaries, resumption, compaction, or handoff; routine self-contained one-step actions need no records.
license: MIT
---

# Project continuity

A fresh agent in the same project must be able to continue authorized work without the previous conversation or a planned handoff. Keep a small, reliable continuation path and selected useful knowledge. Do not rely on remembering to save at the end of the session.

## Establish continuity before substantive work

1. For substantial multi-step coding, research, analysis, or writing, establish the project root from the user's designated folder or existing project entrypoint. A task that might finish in one session still needs continuity. Routine self-contained one-step actions are exempt. Changing directories does not create another project root.
2. Read applicable local instructions and existing state when missing from the current context. Preserve user instructions, existing record conventions, and unrelated work.
3. Before substantive task execution, create any missing part of the minimal continuation path: local AGENTS.md with an explicit pointer to one authoritative current-state record, and an initial state with the intended outcome, exact material requirements, current position, and next action. If an existing equivalent serves this purpose, use it instead of creating a parallel record. Do not ask for a handoff request before doing this.
4. The entrypoint must tell a fresh agent to read the current-state record before substantive project actions. Linked files are not assumed to load automatically. Keep the entrypoint small: enduring instructions and useful pointers, not a competing detailed status summary.

These are required setup steps for applicable work, not optional cleanup. The common case needs only the entrypoint and one small state record. [Record examples](references/records.md) are optional when a layout example or record-ownership guidance is useful; do not read them on every task.

## Keep a usable current state

Maintain enough information to recover the task without the earlier conversation:

- Active goal and status, including explicit completion when reached.
- Exact accepted constraints and clarifications that change the work; link a durable specification instead of copying it when sufficient.
- Consequential completed and pending work, decisions and reasons, and relevant artifact or source pointers.
- Material uncertainty and the limits of actual evidence. Distinguish changed files, successful command results, checks that ran, and things not checked.
- In-flight operations: needed intent, identifier or retrieval path, observed outcome or unknown status, and any session-specific limitations.
- Next useful action, or an explicit indication that no active work remains.

Use concise prose and omit irrelevant fields. Keep secrets and unrelated private information out of records. Preserve unique requirements and results directly when their original source may not remain accessible. Do not assume the next agent can retrieve the chat or a session-bound process handle.

## Checkpoint during the work

- Save unique accepted requirements and costly-to-reconstruct discoveries promptly.
- Refresh current state after each completed coherent unit of work, before moving to another substantial unit or yielding to the user, and before compaction or handoff. Examples include completing a requested report, finishing a coherent implementation slice, finding a cause that changes the next approach, or resolving a material user decision. Batch ordinary commands and edits inside the work unit; do not checkpoint every command.
- If a long work unit produces an important intermediate finding or state transition, save it rather than waiting for the whole unit to finish. The checkpoint must reflect what is actually known, not the intended final result.
- Before an operation whose outcome could outlive current context, preserve needed intent when it would otherwise be lost. Save its identifier when available and its actual outcome when received. An intention is not proof of execution; absent output is not proof of failure.
- A checkpoint supports continued execution. Do not pause or seek approval merely because state was saved.
- When work completes, clear obsolete next actions and retain the useful outcome, deliverable pointers, and durable discoveries. Do not make a fresh agent infer completion from an old task list.

This permits recovery from the last durable checkpoint, not a guarantee of preserving the final unsaved thought or interrupted operation. Never imply exact forced-termination recovery without evidence.

## Resume with a fresh agent

1. Read local AGENTS.md and its authoritative current-state record before substantive project actions when context is missing. Reuse already available context in a continuing session; supporting references are read only when needed.
2. Reconcile the current user request with saved work. Continue the saved objective when requested; honor replacements and new tasks. A saved plan or proposal does not override the current request or expand authorization.
3. Recover the goal, exact constraints, consequential position, uncertainty, and next action. If a gap or contradiction affects that action, consult the relevant source or operation output. Required behavior comes from applicable user instructions; files and results establish implemented or observed behavior. Preserve meaningful disagreements instead of silently dropping requirements.
4. Before repeating a consequential operation with an unknown outcome, use its relevant status or output to resolve uncertainty when possible. Do not blindly repeat a mutation or presume that a process survived. If uncertainty blocks safe continuation, identify that specific blocker and continue independent authorized work.
5. If essential context remains missing, use [recall](../recall/SKILL.md) for that gap only and save the supported result. Sufficient state needs no transcript search. Resume the next useful action without restarting completed work or broad discovery.

## Retain useful knowledge, not a diary

- Preserve reusable successful procedures, consequential decisions with reasons, important pitfalls and supported corrections when they prevent costly rediscovery or repeated mistakes. Do not restrict memory to failures.
- Put knowledge in the appropriate existing documentation or a small topic note. Keep one authoritative home for each maintained fact; short summaries and pointers may refer to it.
- Preserve exact wording, commands, identifiers, inputs, sources, or versions when their details affect correctness. Keep hypotheses labeled; repeated summaries do not turn an inference into a fact.
- Keep a few material unresolved questions with current state. Create a separate queue or stable IDs only when they improve actual use. Record user answers accurately; an unanswered proposal is not authorization. Keep trivial observations and resolved questions out of active state.
- Correct disproved or superseded actionable notes in their authoritative location. Update affected next actions and pointers; preserve distinctions still needed for supported inputs or environments.
- Consolidate when a contradiction, repeated rediscovery, or difficult retrieval demonstrates a need. Do not add a wiki, scheduled whole-project dreaming, append-only task history, or broad audit trail by default. Requested reports and substantive task artifacts remain legitimate deliverables.

## Scope and maintenance

Record checks only if they actually ran and preserve their relevant limits. Memory maintenance does not require additional tests, smoke checks, independent confirmation, or evidence artifacts. Use the requested operation's returned result according to its semantics.

Preserve unrelated work and local customizations. If authorized parallel work occurs, assign one owner to shared current state and integrate other agents' findings without lost updates. This skill does not authorize delegation, commits, pushes, publication, account changes, or unrelated changes. It does not grant permission to restart an operation with unresolved consequential effects.

Reuse existing filenames and indexes. When restructuring within scope, preserve unique useful information, update affected pointers as part of the edit, and remove superseded actionable copies rather than creating backups or competing summaries.

Adapted from pstack's [Session pickup](https://github.com/cursor/plugins/blob/f713f14203cd6420cec13cd7c55c32d598dbab68/pstack/skills/poteto-mode/playbooks/session-pickup.md), [Pause safely](https://github.com/cursor/plugins/blob/f713f14203cd6420cec13cd7c55c32d598dbab68/pstack/skills/poteto-mode/playbooks/pause-safely.md), and the store/gates ideas in [Orchestrate](https://github.com/cursor/plugins/blob/f713f14203cd6420cec13cd7c55c32d598dbab68/pstack/skills/poteto-mode/playbooks/orchestrate.md), plus the user's continuity requirements. This custom version was revised for abrupt fresh-agent continuation and selective durable knowledge. Original MIT notice: [LICENSE](LICENSE). Installed resources are sufficient; no source clone is required.
