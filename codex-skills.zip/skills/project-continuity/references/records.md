# Project record examples and ownership

Optional guidance when creating an entrypoint, choosing an equivalent state owner, or restructuring records. The required workflow lives in SKILL.md; reading this reference is not a prerequisite for each task. Keep existing project conventions when they already provide reliable continuation.

## Minimal continuation path

```text
project/AGENTS.md
       |
       +--> current-state.md       Required for a fresh agent
                   |
                   +--> existing specifications, source, and artifacts
                   +--> selected topic notes, only when useful
```

The state filename is a default, not a migration requirement. Use one authoritative current-state owner; do not create another merely to match this example.

## Local entrypoint

Preserve existing instructions. Add or maintain a short continuation section such as:

```markdown
## Continuation

- When starting with missing project context, read current-state.md before substantive project actions. It owns the active objective, exact accepted requirements, consequential progress, uncertainty, in-flight work, and next action.
- Follow the current user request. Use the saved next action when continuing this work; do not restart completed work or treat a recorded proposal as authorization.
- Reuse context already available. Read supporting records only when their detail affects the task.
- Maintain current state at coherent work boundaries and before yielding or compaction. Save unique requirements and costly-to-reconstruct discoveries promptly; do not rely on a final handoff.
```

Use the real project-relative state path and Markdown links when appropriate. Do not leave placeholder paths or empty structures. If a project already uses a `Codex persistent-state index` with `codex-state-index:start` and `codex-state-index:end` markers, update that section in place instead of appending another index. New projects do not need those markers.

The entrypoint is for enduring instructions and short pointers. Keep active goals, task status, and next actions in their state owner rather than maintaining duplicates. A new agent must reach the essential state from the root alone, without the old chat or a user-supplied file list. Supporting references can be conditional; the canonical current-state read is required for a fresh agent on this project.

## Current-state example

Use the following information as relevant; concise combined sections are fine. This is an example of content, not a required schema or a demand for new checks.

```markdown
# Current state

## Goal and status

The actual intended outcome and whether the work is active or complete.

## Accepted requirements and decisions

Exact material constraints and clarifications, with short reasons or links to their authoritative specification. Separate accepted decisions from proposals.

## Current position

Consequential completed and pending work, useful findings, deliverable locations, and relevant evidence limits. Describe actual outcomes; do not imply tests ran when they did not.

## Operations and uncertainty

Any in-flight operation's intent, identifier or retrieval path, observed or unknown outcome, and recovery limitations. Material blockers or questions. Say when there are no known pending operations if that prevents ambiguity.

## Next action

The first useful continuation action, or explicit completion with no active next step.
```

A useful state note can be much shorter than the example. Preserve exact user distinctions over arbitrary line limits. Include version, input, or date information when it changes the interpretation of a result; do not require extra probes to populate metadata.

A saved current value can become stale. Prefer a pointer to authoritative files when they are cheap to consult. Preserve information directly when it would otherwise be unavailable, such as a unique clarification or a consequential observed result.

## Durable knowledge and open questions

Retain decisions, successful procedures, and supported corrections in the most suitable existing document. A topic note is useful only when there is useful information without a better existing home. Link it from the entrypoint or state when relevant. Do not duplicate entire transcripts, raw datasets, or configuration merely to claim completeness. Keep secrets and unrelated private material out of records.

Keep a few material open questions in current state. Use a separate queue only when the number or lifecycle of questions warrants it. A sufficient entry identifies the unresolved decision, affected work, available evidence, and actual user answer when received. Add IDs only when references need them.

When resolved, put the accepted requirement or decision in its authoritative home and remove obsolete pending language. A suggestion is not an accepted requirement, and silence is not approval.

## Maintenance without a second workflow

Refresh state during real work at the boundaries specified in SKILL.md. Correct affected claims and pointers as part of the edit. Preserve unique useful information before removing obsolete narration. Do not perform a separate cold-start audit, test run, link scan, or whole-history reconciliation merely because records were updated.

When work completes, make the state explicitly complete. Retain useful outcomes and knowledge; remove obsolete instructions to continue. Recovery is from the last durable save. Neither a pointer nor a process identifier guarantees access to an old session or an unobserved outcome.
