---
name: youtube-media-download
description: Download YouTube video or audio to a local file with yt-dlp, including format and size choices and proxy or cookie access. Use for requests to save YouTube media; use youtube-captions for caption-only requests.
---

# YouTube media download

Download the requested media with the installed `yt-dlp`. Keep this workflow limited to video and audio; use `youtube-captions` when the request is only for existing subtitles.

## Establish the request

- Resolve the URL, durable output directory, full video versus a time range, video versus audio only, and any size or codec limit. A URL `t=` parameter changes the playback start; it does not itself trim the downloaded file. For a requested time range, check the current `--download-sections` syntax in `yt-dlp --help`; it needs FFmpeg.
- Use `--no-playlist` unless the user explicitly requests a playlist. Quote URLs and paths. Avoid overwriting an existing file; verify it or choose a distinct name.
- Make routine format choices from the request. Ask only when a material tradeoff cannot be resolved from the user's constraints.

## Probe the live path

- Invoke normal `yt-dlp` so its user configuration and Deno/EJS support remain available. If a required command is missing, consult the runtime guide or workstation inventory.
- For a fresh machine or missing runtime, use the sibling [youtube-captions runtime guide](../youtube-captions/RUNTIME.md) for yt-dlp, Deno/EJS, and FFmpeg provisioning. Copying this skill alone does not install those commands; adapt the instructions to the target host.
- Normal `yt-dlp` uses inherited proxy settings. Investigate proxy configuration only if the requested operation fails; do not start a proxy or change settings as a side effect.
- When format selection requires metadata, `yt-dlp --dump-single-json --skip-download --no-playlist ... "$URL"` supplies format IDs, codecs, dimensions, `filesize`, and `filesize_approx`. Raw JSON can contain signed media URLs: parse it in memory or in a mode-0600 temporary file and print only fields needed for a choice.

## Handle access failures

- If YouTube returns `Sign in to confirm you’re not a bot`, do not keep repeating the same anonymous probe. The challenge can occur even through a working proxy. Ask before reading browser-session cookies or using credentials unless the user already authorized it.
- A supplied Netscape cookie file is sensitive session data. Check its format and permissions without printing cookie values. Use a mode-0600 temporary copy with `--cookies` because `yt-dlp` may write back to that path; remove the copy on exit. Reduce exposed permissions on a user-owned source file when appropriate. Never log, commit, or retain cookie values or signed media URLs.
- Chrome cookie decryption needs access to the matching GNOME keyring and the relevant packaged dependencies. The active official Linux standalone yt-dlp bundles its own Python dependencies; installing `secretstorage` into system Python does not repair that executable. Diagnose the actual error before changing runtimes, or use an authorized user-supplied Netscape cookie file.

## Select and download

- When selecting a specific format, read formats for this video; IDs and sizes vary by video. For audio-only, prefer a directly available audio stream that meets the requested cap. A WebM file may contain only Opus audio: do not transcode solely because its extension is `.webm`.
- For a size cap, prefer an exact `filesize`; treat `filesize_approx` as an estimate. For separate video and audio streams, add both sizes. If no direct format fits, explain the size-versus-quality cost of transcoding or shortening and wait for a choice. Do not silently lower quality or truncate content.
- Download with the chosen output path, adding `--no-playlist` unless the user requested a playlist, and `-f "$FORMAT_ID"` and proxy/cookie options when needed. Do not use `--ignore-config` or add redundant JavaScript-runtime flags. Keep the original cookie file unchanged by using the temporary copy.

## Check the deliverable and report

Read the download command result and identify each requested output. Before reporting success, confirm that each file exists and is nonempty, and check for `.part` files associated with that download. Report a remaining partial file or other failure; do not treat an unrelated `.part` file as evidence about this download.

Compare actual file size with any requested cap, distinguishing MB (1,000,000 bytes) from MiB (1,048,576 bytes). When the request specifies streams, codecs, or duration, use `ffprobe` to check the applicable properties and report any unmet constraint. If a required check cannot be performed, state that limitation instead of claiming the constraint was met. Report the output path and observed result.

File existence, the absence of partial files, and `ffprobe` metadata do not establish that every byte decodes or that the content is complete; do not claim more than the evidence shows.
