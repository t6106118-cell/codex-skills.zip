# Statechart

A Codex skill for finite TLA+/TLC model checking and Mermaid/PNG statecharts.
This package includes the locally adapted scripts, tests, fixtures, TLC1.7.4 jar
and retained upstream license notices.

## Install

For a new installation, from the repository root, copy the complete folder into
your Codex skills directory (the target must not already exist):

```bash
mkdir -p "$HOME/.codex/skills"
cp -a skills/statechart "$HOME/.codex/skills/statechart"
node "$HOME/.codex/skills/statechart/scripts/statechart.mjs" --help
```

If `statechart` is already installed, replace that installation rather than nesting
this folder inside it. Keep any user-created models outside the skill directory.
Reload your Codex session to discover a newly installed skill.

Requires Node.js and npm (verified with Node24) and Java11 or later. PNG output
installs the pinned rendering packages into the user's cache on first use.
The model checker jar is bundled. A copied installation works independently of
this repository checkout.

Read [SKILL.md](SKILL.md) for the workflow and [RUNTIME.md](RUNTIME.md) for runtime
requirements, exact versions, provenance, restoration and verification limits.
The original skill's MIT notice is in [LICENSE](LICENSE); the bundled jar retains
its embedded license notices. A passing finite model does not establish that the
application implementation is correct.
