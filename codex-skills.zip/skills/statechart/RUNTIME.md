# Statechart runtime

The skill folder includes its scripts and TLC jar; the external runtimes below
are still required. Its default location is `~/.codex/skills/statechart`; honor
`CODEX_HOME` if set. Commands can run from any directory.

## Requirements and locations

| Component | Installed runtime |
| --- | --- |
| JavaScript | `node` and `npm` from PATH; verified with Node 24 |
| Model checker | `tools/tla2tools.jar`, TLC 1.7.4, relative to this skill |
| Java | `java` from PATH, Java 11+; this workstation has OpenJDK 25 |
| PNG renderer | `pele@1.8.0` and `@resvg/resvg-js@2.6.2` |
| Renderer cache | `$XDG_CACHE_HOME/statechart/pele-1.8.0-resvg-js-2.6.2`, otherwise `~/.cache/statechart/pele-1.8.0-resvg-js-2.6.2` |
| Font selection | Optional `fc-match` from fontconfig; available on this workstation |

The renderer installs its exact package versions with npm on first use, with
install scripts disabled and normal audit/integrity checks enabled. Its cache
and lockfile are outside the source checkout. Once populated, rendering and
model checking need no network. There is no mise, second Java, or Cursor dependency.
Commands without PNG output do not load the rendering packages.

`TLA2TOOLS` can override the jar path, and `JAVA` can select a Java command on PATH
or an absolute executable path. Missing explicit paths are errors. The default jar is
resolved from `import.meta.url`, not the current directory.

## Run

```bash
node "${CODEX_HOME:-$HOME/.codex}/skills/statechart/scripts/statechart.mjs" from-chart /absolute/path/flow.mmd --png
node "${CODEX_HOME:-$HOME/.codex}/skills/statechart/scripts/statechart.mjs" from-spec /absolute/path/Model.tla --png
node "${CODEX_HOME:-$HOME/.codex}/skills/statechart/scripts/statechart.mjs" render /absolute/path/flow.mmd --out /absolute/path/flow.png
```

Use `from-spec --help` or `from-chart --help` for mappings, finite configurations,
`--fixed`/`--against` comparisons, and expected broken rules. Exit 0 means the
check matched expectations, 1 means an unexpected rule or chart mismatch, and 2
means the operation could not finish. An expected broken rule is still broken.

## Provenance and maintenance

Skill source: [cursor/plugins, pstack/skills/statechart](https://github.com/cursor/plugins/tree/9580c23696ac8d7abed0c166f2f9918800afb819/pstack/skills/statechart),
revision `9580c23696ac8d7abed0c166f2f9918800afb819`, locally adapted on 2026-10-24.
The original MIT notice is retained in [LICENSE](LICENSE).

Local changes: Codex invocation metadata and scope, runtime instructions and
evidence limits, bundled TLC with system Java instead of mise auto-installation,
corresponding runtime tests, and enabled npm audit. Model-checking, parsing,
comparison and rendering algorithms are otherwise retained.

TLC binary: [official v1.7.4 release](https://github.com/tlaplus/tlaplus/releases/tag/v1.7.4),
asset `tla2tools.jar` (2,274,532 bytes). SHA-256:

```text
936a262061c914694dfd669a543be24573c45d5aa0ff20a8b96b23d01e050e88
```

This matches the pinned hash in the original skill and was checked before execution.
The unmodified jar includes `License.txt` (Microsoft Research MIT notice) and
`META-INF/LICENSE.txt` (EPL 2.0 notice). Keep these embedded notices intact.

To restore a missing jar, download the exact release asset to `tools/tla2tools.jar`
and verify the hash above before running it. Do not silently replace it with a
rolling prerelease: these scripts parse TLC 1.7.4 output.

To rebuild the renderer cache, remove only the versioned cache folder listed
above, then run `render`. Keep the versions in `scripts/render.mjs` pinned unless
the rendering behavior has been checked with replacements.

Skill structure and invocation follow the [official Codex skill documentation](https://developers.openai.com/codex/skills).

## Installation verification (2026-10-24)

Eleven selected tests passed with no skips: parsing, chart-to-TLA generation,
help and runtime failures, an independent copied installation, chart/model
round trips, bug detection and fix comparison, and PNG success/failure behavior.
These were focused checks, not a run of the entire upstream suite.

A separate run from `/tmp` produced both overview and counterexample PNGs;
both were visually inspected. The example found an offline/synced state through
two events, matching its violated invariant. Missing Java/jar cases fail clearly.
The installed folder has no symlinks and no source-workspace path references.
`quick_validate.py` passed; npm listed the exact renderer versions and its audit
reported zero vulnerabilities at installation time.

This skill is useful for finite state models of lifecycle, protocol and
concurrency behavior. Building a faithful model takes work: results apply to
the modeled bounds and assumptions, and implementation bugs require a real-code
reproduction. The skill does not automatically verify arbitrary application code.

## Newer upstream pipeline

The upstream rewrite is installed alongside the original pipeline under `upstream/` to retain chart-to-spec and comparison commands. Run `upstream/scripts/statechart SPEC.tla` as described in [its workflow](upstream/WORKFLOW.md). The launcher defaults `TLA2TOOLS` to this installation's bundled jar and uses system Java; explicit `TLA2TOOLS` and `JAVA` overrides remain available. It requires Node 22.18+ or a supported Bun/Deno runtime. The upstream SVG rendering guidance uses Pele 1.9.0, installed on 2026-10-31 at `$XDG_CACHE_HOME/statechart/pele-1.9.0`, or `~/.cache/statechart/pele-1.9.0` if `XDG_CACHE_HOME` is unset. See [render.md](upstream/references/render.md) for its import path and restoration command. The original pipeline's pinned PNG renderer remains unchanged.

The upstream copy was installed from cursor/plugins main on 2026-10-31. On 2026-11-02, its script files were compared with commit `ae5650febf4320793844c12c4adaa937f417f8da`: all match except the deliberately adapted launcher, which supplies the bundled `TLA2TOOLS` path. The workflow and rendering reference retain the local system-Java, bundled-jar, and Pele-cache instructions. No compiler update was needed. The original pipeline remains based on the separate revision recorded above.
