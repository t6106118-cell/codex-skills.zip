#!/usr/bin/env bash
# Find an individually run npm test file that creates a given path.
# Usage: find-polluter.sh <path_to_check> <test_glob>
# Exit codes: 0 target not created | 1 polluter found | 2 search inconclusive
set -euo pipefail

if (( $# != 2 )); then
  printf 'Usage: %s <path_to_check> <test_glob>\n' "$0" >&2
  exit 2
fi

pollution_check=$1
test_pattern=${2#./}

if [[ -e "$pollution_check" || -L "$pollution_check" ]]; then
  printf 'Cannot search: target already exists: %s\n' "$pollution_check" >&2
  exit 2
fi

# Expand recursive globs without splitting filenames at whitespace. Bash globstar
# also matches zero directory levels (src/**/*.test.ts includes src/a.test.ts).
shopt -s globstar nullglob dotglob
IFS=
candidates=( $test_pattern )
unset IFS
test_files=()
for candidate in "${candidates[@]}"; do
  if [[ -f "$candidate" ]]; then
    if [[ "$candidate" == /* ]]; then
      test_files+=("$candidate")
    else
      test_files+=("./$candidate")
    fi
  fi
done

if (( ${#test_files[@]} == 0 )); then
  printf 'No test files match: %s\n' "$test_pattern" >&2
  exit 2
fi

count=0
for test_file in "${test_files[@]}"; do
  count=$((count + 1))
  printf '[%s/%s] Testing: %s\n' "$count" "${#test_files[@]}" "$test_file"
  status=0
  npm test -- "$test_file" || status=$?

  if [[ -e "$pollution_check" || -L "$pollution_check" ]]; then
    printf 'Found polluter: %s\nCreated: %s\nTest exit status: %s\n' \
      "$test_file" "$pollution_check" "$status"
    exit 1
  fi
  if (( status != 0 )); then
    printf 'Search inconclusive: %s exited %s without creating the target.\n' \
      "$test_file" "$status" >&2
    exit 2
  fi
done

printf 'Target not created by %s individually run test files.\n' "${#test_files[@]}"
printf 'This does not rule out order-dependent pollution or a runner that ignores the file argument.\n'
