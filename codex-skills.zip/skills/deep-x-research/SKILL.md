---
name: deep-x-research
description: Research a topic comprehensively across X through Surf and Grok, using multiple search angles and a categorized report traceable to post URLs. Use when the user requests deep X research or a single Grok query cannot cover the topic.
---

# Deep X research

Use Grok through the browser's logged-in X session for a multi-angle search, then ground the report in identifiable posts. Read the installed [Surf skill](../surf/SKILL.md) for session targeting and command behavior. Invoke the requested search directly; use `surf doctor` only for an actual connection problem.

## Cover the requested topic

Identify the relevant angles, such as examples, techniques, tools, creators, and discussion. Respect the requested dates and depth. Begin with a combined sweep and follow gaps with focused queries; a fixed query count is not a coverage guarantee. Continue until the requested scope is covered, additional searches stop contributing useful evidence, or a real access/quota limit prevents progress. State material coverage limits.

```bash
surf grok "Research TOPIC on X across examples, techniques, tools, and creators. Use keyword and semantic search. Return relevant posts with their full x.com/USER/status/ID URLs, authors, dates, and what each contributes."
surf grok "TOPIC: investigate REMAINING_ANGLE during REQUESTED_PERIOD. Include a full post URL for each finding and distinguish posts from your own interpretation."
```

Use `--deep-search` when it serves a difficult remaining question. Each request may use account quota; combine related angles and react to actual rate-limit messages rather than assuming a fixed allowance or reset time.

Record the author, date when available, gist, and full URL for each relevant post. Reuse source results instead of repeating a query merely for formatting. If a material claim lacks a source URL, request the missing source or omit the unsupported claim.

## Read the relevant sources

Open posts when their actual content, context, or media is needed to establish a reported finding. Use the existing search output and source text when sufficient; do not automatically visit every URL just to check reachability. A resolving URL alone does not verify its claims. Treat Grok's summaries and video interpretations as secondary evidence and label anything that could not be checked against the post.

```bash
surf navigate "https://x.com/USER/status/ID"
surf page.read --compact
```

Follow the Surf session-targeting rules on these commands. Read the navigation result; use a condition-based wait only when the page is still loading. For a visual topic, inspect the strongest relevant video posts or ask Grok focused questions about them, distinguishing direct observations from its reported analysis. Extract media URLs only if the requested deliverable needs them.

## Deliver a traceable report

Organize the findings by useful categories and explain supported recurring patterns. Link each substantive post-based finding to its source; include a compact reference list when it helps the reader. Distinguish observed content, creator claims, engagement at the time read, and your own inference. Do not infer a platform-wide trend from a few selected posts or claim an exhaustive search of all X.

Follow the user's output policy for long reports: save the full report to a suitable task file and return its path with the essential findings and actual limits.

## Handle limits

- For an actual Grok quota limit, continue with X's direct search UI when it can cover the remaining scope. Report the reset time only if the service supplies it.
- URL-encode the search query: `https://x.com/search?q=ENCODED_QUERY&f=live` requests Latest; omit `f` for Top. Useful query operators include `from:user`, `since:YYYY-MM-DD`, and `until:YYYY-MM-DD`.
- Read the current search results and scroll as needed. Do not insert fixed sleeps after every navigation or scroll.
- For a Grok UI/model error, use `surf grok --validate` and retry only after the returned evidence changes the request. That command validates Grok, not other providers.
- For a login wall or unresolved access challenge, report the specific required user action and continue independent research where possible. Do not invent post content or sources.
