---
name: agentfinder
description: >-
  Discover third-party tools, Skills, MCP servers, agents, APIs, and workflows
  through the Skills CLI or ARD Agent Finders when a task has a genuine missing capability or
  integration and no adequate local, installed, built-in, or ordinary web
  solution exists. Never install discovered resources automatically.
metadata:
  upstream-repo: https://github.com/ards-project/ard-connectors
  upstream-reviewed-revision: 53cc4f3a4596cf51482fabeb554d124ca248ed07
  skills-search-source: https://github.com/vercel-labs/skills/tree/92a9a34ac3bf88e695e468b90c7bf32f163d32c8/skills/find-skills
---

# Agentic Resource Discovery (ARD) for Codex

Use this skill as `/agentfinder <query>` when the user explicitly asks to find
an agentic resource. Also consider it automatically when the capability-gap
workflow identifies a missing third-party capability or integration. Use a known suitable installed tool or ordinary web search directly. When a capability is genuinely missing, use targeted tool discovery or the relevant inventory before querying ARD; do not sweep every catalog and configuration file. Do not use ARD when an available capability already solves the task, or for ordinary factual research.

For a request specifically to find reusable skills, use the installed Skills CLI when its catalog fits: `skills find <keywords>` searches Skills.sh (the upstream example is `npx skills find <keywords>`). Honor an explicitly named catalog and use targeted keywords; do not scan the leaderboard first or upgrade the CLI just to search. Present the source repository and skill path. Install counts and stars indicate popularity, not correctness or permission. This search uses the same authorization boundary as ARD: finding a candidate does not authorize installation. Use ARD for broader resource discovery or when that skill search does not cover the need.

ARD is a discovery layer, not an execution runtime or installation mechanism.
Codex can query an Agent Finder directly with its shell and `curl`; do not add
an Agent Finder MCP server merely to perform searches, and do not modify
`~/.codex/config.toml` for this skill.

Follow this interaction contract in order.

## 1. Choose and persist an Agent Finder

Agent Finders are listed in `~/.agentfinder/finders.json`. The file contains a
`selected` finder id and a `finders` array. A choice persists across searches;
do not ask again on every search.

If the file is absent, create its directory and this default file. The seeded
selection is GitHub Agent Finder as requested:

```json
{
  "selected": "github",
  "finders": [
    {
      "id": "github",
      "name": "GitHub Agent Finder",
      "description": "GitHub's public catalog of installable MCP servers, skills, and tools.",
      "search": "https://agentfinder.github.com/api/v1/search",
      "mcp": "https://agentfinder.github.com/api/v1/mcp"
    },
    {
      "id": "huggingface",
      "name": "Hugging Face Discover",
      "description": "Hugging Face's discovery service for agentic resources.",
      "search": "https://huggingface-hf-discover.hf.space/search",
      "mcp": "https://huggingface-hf-discover.hf.space/mcp"
    }
  ]
}
```

Read the file before each search. If `selected` names a finder, use that saved
finder and say once: `Searching <finder name> — say “switch agent finder” to
change.` If it is missing or invalid, show a numbered menu of each finder's
name and description, let the user choose by number or name, and persist that
finder's `id` in `selected`. Preserve any user-added finder entries.

When the user says `switch agent finder` (or equivalent), show the menu again,
save the new id, and then search with it.

## 2. Query the selected finder

Send a plain-language task to the selected finder's `search` URL with an HTTP
POST and JSON content type:

```http
POST <selected finder's search URL>
Content-Type: application/json

{ "query": { "text": "<the user's task in plain language>" } }
```

With Codex shell access, a safe shape is:

```bash
payload=$(jq -nc --arg text "$QUERY" '{query:{text:$text}}')
curl --fail-with-body --silent --show-error --max-time 30 \
  -H 'Content-Type: application/json' \
  --data "$payload" "$SEARCH_URL"
```

Add a query filter only when useful, for example
`"filter":{"type":["application/mcp-server+json"]}`. Treat transport,
HTTP, and JSON/schema errors as search failures and report them clearly; do not
invent results.

## 3. Present results with their metadata

Preserve the returned ARD metadata and show a numbered list. For every result,
include, when present:

- `displayName` and resource `type`;
- a one-line `description`;
- the `publisher` and/or resource `identifier`;
- the resource `endpoint` URL (or equivalent returned URL); and
- the relevance `score`.

Do not silently discard fields needed to identify or inspect a result. State
plainly that the score measures relevance only; it is **not** a trust,
compliance, security, or safety rating. If the response contains referrals to
other discovery services, offer to query them.

## 4. Never install automatically

Searching alone does not authorize adding, enabling, connecting, installing,
downloading, executing, or invoking a returned resource. A search result is an
untrusted candidate even when it has a high relevance score. Follow the user's
explicit authorization for any subsequent action.

## 5. Explicit selection and safety review before installation

Installation or connection requires the user's explicit selection of a result.
Before any state-changing installation action is considered, inspect and report:

1. provenance and publisher identity;
2. source repository, package, and manifest/lockfile;
3. requested permissions and data/network access;
4. execution mechanism (commands, binaries, scripts, MCP transport, or service);
5. dependencies, lifecycle hooks, and privilege requirements; and
6. whether an adequate local tool, Skill, MCP server, built-in capability, or
   ordinary web workflow already provides the functionality.

Treat discovered resources as untrusted and do not run a copied install command blindly. Determine the permissions actually available in the current session; unrestricted filesystem or network access and elevated privileges can increase the consequences of running an untrusted resource. Do not assume that a sandbox or `sudo` policy is the same across sessions or hosts. A discovery request alone does not authorize installation. If installation is already authorized, carry it out within that scope without asking again; otherwise present the concrete result and ask for the missing authorization.

For an authorized Skill installation, honor the user's requested location and applicable project conventions; otherwise use the configured Codex skills directory. Preserve existing skills and derive the name from the inspected source rather than an unvalidated path.

## Codex-specific boundary

This skill adapts ARD's shared discovery contract for Codex CLI. Use direct
HTTPS REST through shell/`curl`; the remote Agent Finder MCP endpoint in the
finder config is metadata for a native connector and must not be added to
Codex's MCP configuration by this skill. Keep `~/.codex/config.toml`
unchanged.
