# Local PowerPoint runtime

Generated decks, source generators, and previews belong in the task workspace. Set this skill's directory:

```bash
PPTX_SKILL_DIR="${CODEX_HOME:-$HOME/.codex}/skills/pptx"
```

## Node

The package manifest and lockfile pin PptxGenJS 4.0.1. Preserve the image-size 2.0.4 override when restoring dependencies.

```bash
NODE_PATH="$PPTX_SKILL_DIR/node_modules" node build_deck.cjs output.pptx
```

Use `.cjs` for a copied generator so it also works inside projects configured as ES modules. Dependencies are skill-local. Restore them only if missing or broken:

```bash
npm ci --prefix "$PPTX_SKILL_DIR"
```

### Shared graphics packages on this workstation

React, React DOM, React Icons, and Sharp are installed separately at `/home/nova/projects/javascript-graphics-template`. Its manifest and lockfile pin these direct versions:

| Package | Version |
| --- | --- |
| `react` | 19.3.1 |
| `react-dom` | 19.3.1 |
| `react-icons` | 5.7.0 |
| `sharp` | 0.35.5 |

When a CommonJS deck generator needs these libraries alongside PptxGenJS, run:

```bash
NODE_PATH="$PPTX_SKILL_DIR/node_modules:/home/nova/projects/javascript-graphics-template/node_modules" \
  node /absolute/task/build_deck.cjs /absolute/task/output.pptx
```

Use `require('react')`, `require('react-dom/server')`, `require('react-icons/fa')`, and `require('sharp')` as needed. Ordinary JavaScript can use `React.createElement`; the shared environment does not include a JSX/TypeScript transpiler. Native ESM imports do not use `NODE_PATH`; use an application's own package environment for ESM/TSX.

Keep generators and generated assets in the task workspace. Reuse this shared installation instead of installing the packages globally or into each deck folder. If the shared dependencies need restoration, run `npm ci --prefix /home/nova/projects/javascript-graphics-template`. On another workstation, provision this environment or use an appropriate task-local package environment; copying the PowerPoint skill alone does not transfer these libraries.

## Python

Use the skill-local uv environment for bundled helpers and Python presentation scripts. Its locked dependencies include defusedxml, lxml and Pillow for package inspection, schema validation and thumbnails, plus `python-pptx` 1.0.2 for reading, creating, and editing presentations through its supported Python API. Import it as `pptx`.

```bash
"$PPTX_SKILL_DIR/.venv/bin/python" "$PPTX_SKILL_DIR/scripts/qa_deck.py" output.pptx
```

Run task-owned Python presentation scripts with the same interpreter:

```bash
"$PPTX_SKILL_DIR/.venv/bin/python" /absolute/task/build_deck.py
```

Restore at this path, rather than moving a virtual environment with old launcher paths:

```bash
uv sync --project "$PPTX_SKILL_DIR" --locked
```

## External executables

Rendering uses `soffice` and `pdftoppm` on the active PATH. The Office wrapper creates an isolated LibreOffice profile and applies its socket workaround only if the environment requires it. No permanent user-profile change is needed.

`markitdown` is not required. Use the content helper for slide text or a suitable installed document converter for broader extraction. Check actual local font matching when fit matters; a font name in the deck neither embeds nor installs it.
