// HTML main-content adapter for the fetch-url-markdown skill.
use html_extractor::{extract, ExtractOptions};
use std::{
    env, fs,
    io::{self, Read, Write},
    process,
};

fn run() -> Result<(), String> {
    let mut args = env::args().skip(1);
    let mut url = None;
    let mut path = None;
    let mut json = false;
    let mut text = false;
    let mut metadata = false;
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--help" | "-h" => {
                eprintln!("usage: firecrawl-html-extractor [--url URL] [--text|--json] [--metadata] [FILE|-]");
                return Ok(());
            }
            "--url" => url = Some(args.next().ok_or("--url requires a value")?),
            "--json" => json = true,
            "--text" => text = true,
            "--metadata" => metadata = true,
            "-" => {
                if path.replace(arg).is_some() {
                    return Err("more than one input file supplied".into());
                }
            }
            _ if arg.starts_with('-') => return Err(format!("unknown option: {arg}")),
            _ => {
                if path.replace(arg).is_some() {
                    return Err("more than one input file supplied".into());
                }
            }
        }
    }
    if text && json {
        return Err("--text and --json are mutually exclusive".into());
    }
    let mut html = String::new();
    match path.as_deref() {
        None | Some("-") => {
            io::stdin()
                .read_to_string(&mut html)
                .map_err(|e| e.to_string())?;
        }
        Some(p) => {
            html = fs::read_to_string(p).map_err(|e| format!("{p}: {e}"))?;
        }
    }
    let options = ExtractOptions {
        url,
        output_text: text,
        ..Default::default()
    };
    let result = extract(&html, &options).map_err(|e| e.to_string())?;
    let used_fallback = result.stats.as_ref().is_some_and(|s| s.used_fallback);
    if metadata {
        eprintln!(
            "page_type={} extraction_quality={:.4} used_fallback={}",
            result.page_type, result.extraction_quality, used_fallback
        );
    }
    let mut stdout = io::stdout().lock();
    if json {
        let markdown = serde_json::to_string(&result.markdown).map_err(|e| e.to_string())?;
        let page_type =
            serde_json::to_string(result.page_type.as_str()).map_err(|e| e.to_string())?;
        writeln!(
            stdout,
            "{{\"markdown\":{},\"page_type\":{},\"extraction_quality\":{:.4},\"used_fallback\":{}}}",
            markdown, page_type, result.extraction_quality, used_fallback
        )
        .map_err(|e| e.to_string())?;
    } else {
        let output = if text {
            result
                .text
                .ok_or("upstream returned no plain text despite output_text=true")?
        } else {
            result.markdown
        };
        stdout
            .write_all(output.as_bytes())
            .map_err(|e| e.to_string())?;
    }
    stdout.flush().map_err(|e| e.to_string())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("firecrawl-html-extractor: {error}");
        process::exit(1);
    }
}
