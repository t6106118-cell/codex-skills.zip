#!/usr/bin/env python3
"""Smoke-test freshly built adapters and the skill's conversion boundary."""

import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
if len(sys.argv) != 2:
    raise SystemExit("usage: test_adapters.py DIRECTORY_CONTAINING_BOTH_BINARIES")
bin_dir = Path(sys.argv[1]).resolve()
skill_dir = Path(__file__).resolve().parent.parent

ARTICLE = (b'<nav>Discard</nav><main><h1>Research Title</h1>'
           b'<p>This is the first substantive article paragraph.</p>'
           b'<p>This is the second substantive article paragraph.</p></main>')
LINKS = (b'<p><a href="../child">next</a>'
         b'<img alt="embedded" src="data:image/png;base64,AAAA"></p>')
TABLE = (b'<table><tr><th>Name</th><th>Value</th></tr>'
         b'<tr><td>A</td><td>B</td></tr></table>')


def run(name, data, *args):
    return subprocess.run(
        [str(bin_dir / name), *args], input=data, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, timeout=15, check=False,
    )


class AdapterTests(unittest.TestCase):
    def test_faithful_links_data_uri_and_gfm_table(self):
        p = run("firecrawl-html-to-markdown", LINKS + TABLE,
                "--url", "https://example.com/base/page", "-")
        self.assertEqual(p.returncode, 0, p.stderr.decode(errors="replace"))
        output = p.stdout.decode()
        self.assertIn("https://example.com/child", output)
        self.assertIn("data:image/png;base64,AAAA", output)
        self.assertIn("| Name | Value |", output)

    def test_clean_extraction_and_metadata(self):
        p = run("firecrawl-html-extractor", ARTICLE, "--json", "-")
        self.assertEqual(p.returncode, 0, p.stderr.decode(errors="replace"))
        result = json.loads(p.stdout)
        self.assertIn("# Research Title", result["markdown"])
        self.assertIn("second substantive", result["markdown"])
        self.assertNotIn("Discard", result["markdown"])
        self.assertIn("page_type", result)
        self.assertIn("extraction_quality", result)
        self.assertIsInstance(result["used_fallback"], bool)

    def test_invalid_inputs_fail(self):
        bad_url = run("firecrawl-html-to-markdown", ARTICLE, "--url", "relative", "-")
        self.assertNotEqual(bad_url.returncode, 0)
        conflict = run("firecrawl-html-extractor", ARTICLE, "--json", "--text", "-")
        self.assertNotEqual(conflict.returncode, 0)
        self.assertIn(b"mutually exclusive", conflict.stderr)

    @unittest.skipUnless(Path("/dev/full").exists(), "requires Linux /dev/full")
    def test_output_write_failure_is_reported(self):
        payload = b'<p>This single paragraph has enough text for extraction.</p>'
        for name, args in (("firecrawl-html-to-markdown", ["-"]),
                           ("firecrawl-html-extractor", ["-"]),
                           ("firecrawl-html-extractor", ["--json", "-"])):
            with self.subTest(command=name, args=args):
                with open("/dev/full", "wb", buffering=0) as output:
                    result = subprocess.run(
                        [str(bin_dir / name), *args], input=payload, stdout=output,
                        stderr=subprocess.PIPE, timeout=15, check=False,
                    )
                self.assertNotEqual(result.returncode, 0,
                                    "the command reported success after output failed")

    def test_skill_invokes_both_adapters(self):
        script = skill_dir / "scripts" / "fetch_url_markdown.py"
        spec = importlib.util.spec_from_file_location("fetch_url_markdown_test", script)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory(prefix="fetch-adapter-test-") as temporary:
            with patch.dict(os.environ, {"PATH": str(bin_dir) + os.pathsep + os.environ["PATH"]}):
                for clean in (False, True):
                    content = module.html_to_markdown(
                        ARTICLE, "https://example.com/article", Path(temporary),
                        timeout=15, clean=clean,
                    )
                    self.assertIn("# Research Title", content)


if __name__ == "__main__":
    unittest.main(argv=[sys.argv[0]], verbosity=2)
