# PDF Inspector runtime

Updated 2026-11-02. The active native build is upstream version 1.25.2 at source commit `bcf387d1f4ab91d702f417fd9600694da0c166c3`, including the unreleased Windows-font subset/glyph-spacing fixes. Its root is `/home/nova/.local/opt/fedora44-tools/pdf-inspector/1.25.2-bcf387d1f4ab`. Public commands `~/.local/bin/pdf2md` and `detect-pdf` point to its `bin/`; `dump_ops` is bundled there without a public link. The superseded released-1.25.2 installation root was removed.

## Build and restore

Source: [Firecrawl PDF Inspector](https://github.com/firecrawl/pdf-inspector/tree/bcf387d1f4ab91d702f417fd9600694da0c166c3). The source snapshot is `/home/nova/arrg434/upstreams/firecrawl--pdf-inspector` and contains no Git history. The successful install operation was:

```bash
cargo install --path /home/nova/arrg434/upstreams/firecrawl--pdf-inspector --locked --root /home/nova/.local/opt/fedora44-tools/pdf-inspector/1.25.2-bcf387d1f4ab --no-default-features --bins
```

Cargo warned that the snapshot lacked a published Cargo.lock and resolved dependencies; this is not evidence of a reproducibly locked release build. For a future rebuild, generate/retain the chosen lockfile before using `--locked`. Build with the host's Fedora Rust/Cargo and C linker; do not add rustup or a second toolchain just for this skill. Generated target directories were removed after installation.

Promote a successful replacement by updating the two public command links to its exact `bin/` paths, then remove the superseded root. Preserve user data/configuration directly; keep no rollback installation. The upstream version string alone cannot identify these source fixes, so retain the commit and root in runtime records.

## Contract and feature boundary

This build uses the default native extraction features. It does not install PDFium, ONNX Runtime, OCR model caches, or optional Firecrawl OCR. Use the existing OCRmyPDF/Tesseract workflow when the task needs OCR. Native classification/extraction flags and the helper contract remain in SKILL.md.

The recorded CLI contract uses `--help`/`-h` with usage on stderr and exit 1; there is no standalone version-reporting flag. Source build and installation succeeded. No PDF conversion, OCR, or smoke test was run for this update. Earlier released-1.25.2 fixture checks remain historical evidence and do not validate this build.
