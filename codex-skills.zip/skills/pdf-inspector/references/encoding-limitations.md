# Core Windows-font subset decoding: fixed source build

The superseded released 1.25.2 build could misread subsets from fonts such as Arial or Times New Roman when they lack a usable cmap, glyph names, and ToUnicode. Upstream's unreleased changes distinguish the Windows standard glyph order from the Macintosh order and recognize blank spacing glyphs. The same manifest version in a development checkout does not mean those fixes are in the released binary.

Relevant symptoms include shifted quotation marks or dashes, and U+FFFD between otherwise readable words. The latter can make the detector recommend OCR even when the document contains native text.

When these symptoms affect the task, compare the relevant text against the page and, where useful, Poppler extraction. Keep the extraction uncertainty visible; do not silently replace punctuation or classify the document as scanned solely because this text was decoded badly. Use the task's required coverage to decide whether OCR is useful.

The active `1.25.2-bcf387d1f4ab` source build now includes those fixes. This was established from its source and successful build, not a fresh PDF extraction test.

Source: [upstream unreleased fixes](https://github.com/firecrawl/pdf-inspector/blob/bcf387d1f4ab91d702f417fd9600694da0c166c3/CHANGELOG.md). Reviewed on 2026-11-02. The released root was replaced by the source build on this date.
