---
name: surf
description: Control Chrome browser via CLI for testing, automation, and debugging. Use when the user needs browser automation, screenshots, form filling, page inspection, network/CPU emulation, DevTools streaming, or AI queries via ChatGPT/Gemini/Perplexity/Grok/AI Studio.
metadata:
  upstream-repo: https://github.com/nicobailon/surf-cli
  upstream-reviewed-version: 2.26.0
---

# Surf browser automation

Control Chrome through the installed `surf` CLI. Use the existing browser integration directly. For installation or connection repair, read [RUNTIME.md](RUNTIME.md); copying this skill does not install Surf.

## Target the intended tab

Honor an explicitly supplied tab with `--tab-id <id>`. Otherwise choose one stable, unique task-and-agent session name and use it on every shell call:

```bash
surf session.ensure <unique-task-and-agent-name> about:blank
surf --session <unique-task-and-agent-name> navigate "https://example.com"
surf --session <unique-task-and-agent-name> page.read --compact
surf --session <unique-task-and-agent-name> click --ref e1
```

`session.ensure` creates or recovers the session; it reuses a live binding. `SURF_SESSION` is an alternative within a persistent shell, but an export does not persist across independent shell calls. A directory basename alone does not distinguish tasks or agents sharing the directory. Sessions share the Chrome profile's cookies and storage.

## Drive the page

Read the page for current refs before interacting. Prefer deterministic commands for a known path. Use `surf do` for a stable sequence, and condition-based waits (`wait.element`, `wait.url`, `wait.ready`) when readiness is uncertain. A fixed sleep does not establish readiness. Reuse an action's reported page changes when they already answer the next question; request another page read only when needed. For an incomplete change report, read the relevant ref or region rather than automatically dumping the whole page. Stop when the requested outcome is complete and follow the user's verification scope.

```bash
surf --session <name> type "hello" --ref e5
surf --session <name> wait.ready --selector ".results"
surf --session <name> screenshot --full-page --output /explicit/path/shot.png
```

Use normal CLI help for an unfamiliar operation:

```bash
surf --find <term>
surf --help-topic <topic>
surf --help-full
```

Surf 2.26 makes interaction failures explicit: disabled, covered, stale, or rejected controls fail rather than reporting success. Refs belong to their page; refs from an earlier navigation cannot be reused on a new page. Use `check <ref>` or `uncheck <ref>` to set a checkbox state instead of toggling it. `page.text --ref <ref>` retrieves a field's complete value or an element's text; secret fields are refused. `type --escapes` interprets newline/tab escapes only when requested.

## Read only the relevant command reference

The installed runtime is Surf 2.26.0. The [command reference](references/command-reference.md) describes the current command surface; use installed help when more detail is needed. Read only the relevant reference:

- [Oracle](references/oracle.md), [semantic commands](references/semantic.md), [workflows/playbooks](references/workflows.md), [remote Surf](references/remote.md), and [troubleshooting](references/troubleshooting.md) describe the current runtime.
- For core page, input, frame, screenshot, and network commands, use `surf <command> --help` when the required syntax is not already known.
- For X feeds/threads, prefer the existing `use x thread` playbook or `network.wait` / `network.replay` when they expose the needed source data. Use visible-page collection only when an API route does not fit. These operations use the logged-in browser session and remain within the task's existing authorization.
- `semantic.extract` can return selected typed page values without a complete page read. It uses Cloudflare credentials; other optional semantic calls can use TypeSafe or Cloudflare. Follow the semantic reference for data exposure and result states; do not treat an uncertain guess as an extracted fact.
- Use [deep-x-research](../deep-x-research/SKILL.md) for comprehensive X research.

## Interpret failures

Ordinary socket-backed host errors print a diagnostic on stderr and exit 1. `--json` also emits an error object when supported. `--soft-fail` can turn a host error into exit 0 with empty stdout; transport failures still exit 1. Read the actual response rather than assuming exit 0 proves success.

For a socket error, use `surf doctor` and its reported socket path. For `tab_gone` or `session_epoch_stale`, follow the returned recovery command. Use `session.info <name>` for queue state. AI-provider commands take exclusive browser access; a queued request is not evidence of a hung process.

Grok's `--validate` checks Grok only. For another provider, inspect that service's actual failure and UI. Do not repeat a submission with an uncertain external effect merely because a response timed out.
