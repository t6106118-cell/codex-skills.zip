# Surf runtime provisioning

Updated 2026-11-06: npm replaced surf-cli@2.25.0 with surf-cli@2.26.0 in the existing /usr/local prefix and reported 238 packages changed. The command remains /usr/local/bin/surf, backed by /usr/local/lib/node_modules/surf-cli/native/cli.cjs. No second installation was created.

## Existing workstation installation

The package is system-owned, while native-host registration belongs to the user. Update the package with npm, then refresh registration as the normal user:

```bash
sudo -n /usr/bin/npm install --global --prefix /usr/local surf-cli@2.26.0
node /usr/local/lib/node_modules/surf-cli/scripts/install-native-host.cjs --refresh
```

The refresh operation preserves existing browser registrations, allowed extension origins, and persisted listener/socket settings, and adds Surf's new fixed extension ID. It rewrites the user-owned host wrapper to launch the installed package. User settings, saved sessions, and credentials outside the package are not replaced by npm.

Surf 2.26 provides surf update to reinstall/rebuild, refresh native-host registrations and supported skill links, and request an extension reload. It needs write access to its package prefix. Do not run the entire updater as root on this workstation: its user-home operations would target root rather than nova. Use the split package/registration operation above for this system-prefix installation.

The upstream installer manages Claude/pi skill links where those skill directories exist; this personal Codex skill is maintained separately and preserves the user's local guidance.

## Browser activation

The extension now has fixed ID oaclimdkkglbnpekeignmjenkodkaaka. Upgrading from older versions changes the ID once. Refresh registration, then reload the unpacked Surf extension in chrome://extensions, keeping Developer mode enabled. The old-ID copy may remain disabled until Chrome restarts. Extension-local preferences such as Debug Mode do not automatically carry over to the new ID.

The 2026-11-06 registration refresh succeeded for Google Chrome and wrote /home/nova/.local/share/surf-cli/host-wrapper.sh. The updater's extension-reload operation returned: "No Surf extension is connected, so nothing was reloaded; the browser loads the new version when it starts Surf." The user subsequently reported reloading Surf and explicitly requested a browser test. The first doctor call found no socket; no Chrome browser process was running. After launching Chrome, a task-owned browser session worked. Final doctor returned OK with CLI, native host, and extension all at 2.26.0. Reading a normal HTTP page, checkbox check/check-again/uncheck, escaped multiline typing, complete field-value retrieval, and rejecting a disabled button were exercised successfully. The disposable test session was closed. AI-provider workflows were not tested.

For a connection or version-skew error during actual work, use surf doctor and its reported recovery path. Do not add a mandatory post-update smoke test. Do not create a placeholder socket if /tmp/surf.sock is absent.

## Skill source

The 2.26 behavior and command updates were reviewed from the user-provided /home/nova/a78gp/surf-cli-main source archive, whose package.json reports 2.26.0 and changelog dates that release 2026-11-04. A Git commit was not established for the archive. Updated the entrypoint, command reference, and installation-related reference instructions while retaining local session targeting, bounded reads, optional validation, and accurate semantic-service guidance.
