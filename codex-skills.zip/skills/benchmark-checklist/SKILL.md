---
name: benchmark-checklist
description: Design or assess performance measurements and speedup claims. Use when benchmarking, investigating a measured regression, or choosing between options based on performance; distinguish quick estimates from evidence for consequential comparisons.
license: MIT
---

# Benchmark checklist

Use the smallest measurement that answers the user's actual question. Respect explicit instructions on scope and verification. Distinguish a quick estimate, a comparison of the configurations as provided, and a recommendation about options that could reasonably be tuned; they support different conclusions.

Before measuring, identify the claim, workload, units, timed boundary, and what the measurement excludes. Read or reuse the existing harness and environment where relevant. Do not silently change the workload or configuration; document meaningful differences. For a quick ballpark, a single run can suffice if labeled as such.

For the claim at hand, consider the risks that could invalidate it:

- **Work and correctness:** Ensure the intended work occurs inside the measured interval and produces the expected result. Account for errors, rejected requests, timeouts, retries, lazy execution, caching, and discarded results where relevant.
- **Representative conditions:** Match the user's intended workload, data, concurrency, build mode, settings, and warm or cold state. A comparison of defaults answers a different question from a comparison of tuned options. If tuning matters and is not done, limit the conclusion accordingly.
- **Noise and repeatability:** For a consequential comparison, use enough runs to understand variation, interleave alternatives when practical, and report the run count and spread alongside a suitable summary. A difference obscured by variation is inconclusive. Account for competing load when it can affect the result.
- **Plausibility and relevance:** Check results against applicable resource limits and the fraction of the end-to-end path affected. For example, eliminating a component that consumes 10% of total time can improve overall speed by at most about 11% if everything else is unchanged. Separate microbenchmarks from user-visible effects; measure the latter when the question depends on it.
- **Bottleneck:** Identify the limiting component when necessary to explain a result or choose an optimization; consider whether the load generator is the bottleneck rather than the system being measured. Use profiling or other diagnostics when they can change the decision, and distinguish instrumented runs from reported timings.

Report the result and its practical scope: workload, units, configurations, number of runs, variability when measured, correctness or error evidence when relevant, and material limitations. Say when the evidence is inconclusive; do not infer a cause or claim a speedup that the measurements do not support.
