---
name: maintain-formal-verification-skill
description: Review and update a project's existing formal verification artifacts or project-local verification skill when covered code changes. Use for model or proof drift, stale verification, or explicit formal-check maintenance; not for creating a new verification system or ordinary tests.
license: MIT
---

# Maintain formal verification

A passing formal check can describe an outdated model instead of current code. Determine whether the verification still represents the covered behavior, then update it within the user's authorized scope. This workflow works with existing models, proofs, harnesses, and project-local skills; no particular generator is required.

Identify the requested checks, covered files and behavior, properties, assumptions, bounds, tool commands and versions, and last established correspondence to the code. Read project instructions and use existing records and source history where available. If no reliable correspondence baseline exists, say so and inspect the relevant current implementation and model; do not invent a sync commit.

Compare relevant code changes with the verification, including moved code and new paths affecting the covered state. Distinguish changes that leave the modeled behavior unchanged, modeling drift, evidence of an intentional change to the promised property, and a possible product bug. Ground the model's steps and assumptions in the actual code, including the boundaries of atomic actions. A model may abstract behavior, but state what it omits.

When updates are authorized, change the verification to reflect the code, not to force a pass. Change a property only when evidence or the user's instructions establish that the requirement changed; explain the change. Preserve meaningful bounds or report changes and their consequences. Do not change product behavior unless the user requested or authorized it. A counterexample in a model is not automatically a real-code bug: trace or reproduce the relevant path when needed and permitted, and identify modeling errors separately.

Run the relevant existing checks when appropriate and permitted by the user's instructions. A baseline, a negative control, or a reproduction can be useful when it answers a material uncertainty; do not impose them as universal requirements. Report what actually ran and what remains unverified. A passing bounded model establishes only its checked properties under its stated model, bounds, and assumptions.

Update an existing coverage or sync record only after establishing the corresponding code and verification state; do not mark blocked or unverified work as confirmed. Report whether each check is in sync, was updated, reveals a supported bug, or remains unresolved, with the evidence, assumptions, bounds, and relevant limitations. An updated model can reveal a bug; report both outcomes when applicable. For a TLA+ visualization, use the installed statechart skill when it helps the task; its use is not mandatory.
