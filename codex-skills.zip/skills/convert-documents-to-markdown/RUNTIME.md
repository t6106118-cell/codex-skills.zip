# AnyDoc runtime

Updated 2026-11-02. The active package is `@firecrawl/anydoc@0.2.4-e7178e099b6b`, built from [upstream source](https://github.com/firecrawl/anydoc/tree/e7178e099b6bf9171e2c52b832cbdb4134b69112). It includes the upstream table-header collision fix and hosted Parse-mode option. Its embedded PDF dependency was updated to the same fixed PDF Inspector source commit `bcf387d1f4ab91d702f417fd9600694da0c166c3` used by the dedicated PDF commands.

Active root: `/home/nova/.local/opt/fedora44-tools/anydoc/0.2.4-e7178e099b6b`. `~/.local/bin/anydoc` points to its `bin/anydoc`, which points to `node_modules/@firecrawl/anydoc/cli.js`. Node 20+ is required; the workstation uses Fedora Node 24. The native Linux x64 GNU addon is included in this local package. It does not rely on an older platform package to supply its binary. The old released-0.2.4 root was removed.

## Installation artifact and restoration

The installable package is `/home/nova/arrg434/build-packages/firecrawl-anydoc-0.2.4-e7178e099b6b.tgz`. A fresh installation can use:

```bash
npm install --prefix "<versioned-root>" --save-exact --omit=dev --omit=optional "<package-archive>"
```

Create `bin/anydoc` pointing to the package CLI, promote the public command, and remove the superseded root. Retain the normal npm integrity checks, package.json and package-lock.json. User environment/API settings are separate from this installation.

## Source rebuild

The history-free source directories are `/home/nova/arrg434/upstreams/firecrawl--anydoc` and its sibling `firecrawl--pdf-inspector`. To restore elsewhere, download the two exact commits recorded above and retain an equivalent sibling layout.

Local build changes: AnyDoc's Cargo.toml points `pdf-inspector` at the fixed sibling source. In `node/package.json`, the package version identifies the AnyDoc commit and the files list includes `anydoc.linux-x64-gnu.node` and `LOCAL_SOURCE.json`. The latter records both commits and local packaging changes.

Use the retained node/package-lock.json with `npm ci`, then `npm run build` in `node/`. Pack with `npm pack` after including the generated native addon, and install that archive into a versioned user-local prefix. Source Rust target directories were removed after packaging; a future rebuild recreates them. The ordinary npm audit reported a high-severity build dependency, and `npm audit fix` changed one package and reported zero vulnerabilities before the final build.

## Runtime behavior and limits

Normal conversion stays local. Supported input formats and exit codes remain in SKILL.md. Scanned/image-only pages require an explicit OCR choice; hosted OCR sends the document to Firecrawl. The new `--parse-mode auto|fast|ocr` option applies only to an explicitly selected hosted workflow. Do not enable hosted processing merely because it is available.

The native build, local npm package installation, command promotion, and old-root removal completed successfully. No document conversion or account workflow was run for this update; compilation is not a conversion test.
