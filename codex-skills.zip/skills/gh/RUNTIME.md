# GitHub CLI runtime provisioning

This skill documents the `gh` command; it does not contain the executable or
require a registered MCP server. On a fresh Fedora machine, install GitHub CLI
using [GitHub's supported RPM instructions](https://github.com/cli/cli/blob/trunk/docs/install_linux.md#rpm).
For DNF5, those instructions use:

```bash
sudo dnf install dnf5-plugins
sudo dnf config-manager addrepo --from-repofile=https://cli.github.com/packages/rpm/gh-cli.repo
sudo dnf install gh
```

Inspect existing repository configuration first and keep package-signature
verification enabled. Verify the executable with `command -v gh` and
`gh --version`. This skill is pinned to GitHub CLI v2.103.3; if the installed
version differs, check its help before relying on version-specific options and
update the skill when appropriate. Authentication is separate: use
`gh auth status` and sign in with `gh auth login` when GitHub access is needed.
