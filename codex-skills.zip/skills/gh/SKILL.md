---
description: Patterns for invoking the GitHub CLI (gh) from agents. Covers structured output, pagination, repo targeting, search vs list, gh api fallback.
metadata:
    github-path: skills/gh
    github-pinned: v2.103.3
    github-ref: refs/tags/v2.103.3
    github-repo: https://github.com/cli/cli
    github-tree-sha: 8b5983f05b6502d3cdce2146383429b8ea59e8fc
name: gh
---
# Reference

For installing or checking the `gh` executable after copying this skill, see
[RUNTIME.md](RUNTIME.md). Copying the skill does not install or authenticate it.

## Interactivity policy

`gh` already does the right thing in non-TTY contexts: it skips the pager,
strips ANSI color, and errors out fast with a helpful message instead of
prompting (e.g. `must provide --title and --body when not running interactively`).
You don't need to defensively set `GH_PAGER` or pass `--no-pager` (no such
flag exists).

## Parsing JSON

Human output from `gh` is column-formatted. If you want structured data:

- Add `--json field1,field2,...` for structured output.
- For `gh issue view` and `gh pr view`, use `--json ...,comments` to include comments in structured data; use `--comments` only with the human-readable view.
- Run a command with `--json` and **no field list** to print the full set of
  available fields, then pick what you need.
- Use `--jq '<expr>'` for filtering without piping through a separate `jq`.
- Use `--template '<go-template>'` (alongside `--json`) when you want shaped
  text output. Note that `--template`/`-T` collides with a body-template flag
  on a few commands (e.g. `gh pr create -T`, `gh issue create -T`); always
  check `--help` before assuming which one you're hitting.

## Pagination and silent truncation

List commands cap results.

- `gh issue list`, `gh pr list`, `gh search ...`: pass `-L N` (`--limit N`).
  The default is usually 30.
- `gh issue list` / `gh pr list` do not expose aggregate totals like
  `totalCount` via `--json`. If you need a true total, use `gh api graphql`
  to query `totalCount`; otherwise, treat `-L` as the cap for the current call.
- For raw API calls use `gh api --paginate <path>`. Combine with
  `--jq` and (optionally) `--slurp` to assemble one array.

## Repo targeting

`gh` infers the repo from the cwd's git remotes. 

For commands supporting it, pass `--repo OWNER/REPO` (`-R`) to override the inferred repo. `gh api` takes the owner and repo in its endpoint or GraphQL variables; it does not accept `--repo`.

## Search vs list

- `gh search issues|prs|code|repos|commits|users` uses GitHub's search
  index and accepts the full search syntax (`is:open`, `author:`,
  `label:`, `repo:owner/name`, `in:title`, ...). Pass each qualifier as
  its own bare token, not as one quoted string:
  `gh search issues repo:cli/cli is:open author:monalisa` works, but
  `gh search issues "repo:cli/cli is:open"` is treated as a single keyword (parsed as `repo:"cli/cli is:open"`)
  and fails with `Invalid search query`. Quote only multi-word free text
  (`gh search issues "broken feature"`). Most qualifiers also have a
  dedicated flag (`--repo`, `--author`, `--label`, ...). Prefer search for
  anything cross-repo or filtered by author/label.
- `gh issue list --search "..."` and `gh pr list --search "..."` take the
  query as one quoted string (it is a flag value) and are scoped to one repo.
- Bots author as GitHub Apps, so `--author dependabot` matches nothing. Use
  `--app dependabot` (on `pr`/`issue list` and `search prs|issues`; expands
  to `author:app/<slug>`) or `--author "dependabot[bot]"`.
- `gh search issues` also takes `--search-type <lexical|semantic|hybrid>`
  (github.com/GHEC only, issues only): use `semantic` when the user describes a
  problem in natural language rather than exact terms, and `hybrid` to blend
  keyword and semantic ranking; `lexical` (default) is exact matching.

## Specialized commands

Read only the relevant section of [advanced commands](references/advanced-commands.md) when using:

- [Issue types and relationships](references/advanced-commands.md#issue-types-sub-issues-and-relationships).
- [Image and video attachments](references/advanced-commands.md#attaching-images-and-videos), including partial-upload failure behavior.
- [Discussions](references/advanced-commands.md#discussions-gh-discussion).
- [Issue artifacts](references/advanced-commands.md#issue-artifacts-gh-issue-artifact), distinct from Actions artifacts.
- [Remote repository files](references/advanced-commands.md#reading-files-and-directories-gh-repo-read-file--read-dir).

## Fall back to `gh api` for anything `--json` doesn't expose

Sometimes useful data isn't on the typed commands. Examples:

- Review-thread comments on a PR: `gh api repos/{owner}/{repo}/pulls/{n}/comments`
  (the `--comments` flag on `gh pr view` shows issue-level comments only).
- Arbitrary GraphQL: `gh api graphql -f query='...' -F var=value`.
- REST shortcuts: `gh api repos/{owner}/{repo}/...` - note the
  `{owner}/{repo}` placeholders are filled from the detected repository. Use an explicit `repos/OWNER/REPO/...` endpoint when the target must not depend on the working directory.

## Authentication

- `gh auth status` prints the active host(s), user, and which env var (if
  any) is being honored.
- `gh auth status --json` is supported.
- Stored credentials may be expiring tokens that gh refreshes automatically.
  `gh auth status --json hosts` reports these with `"refreshable": true` and a
  `tokenExpiresAt` timestamp.
- Expiring tokens are not available on every host. So far only github.com
  and GHE.com (`*.ghe.com`) hosts support them; other hosts keep using
  regular tokens.
- Do not cache the output of `gh auth token`: an expiring token can stop
  working at any time because gh rotates it on refresh. Run `gh auth token`
  again each time you need one, or prefer `gh api` over raw HTTP calls so gh
  handles the refresh for you.
- A `refresh_expired` state in `gh auth status --json hosts` means the refresh
  token was rejected. Recovery needs an interactive `gh auth login` or
  `gh auth refresh`, so ask the user to run it instead of retrying.
- Tokens from `GH_TOKEN` or `GITHUB_TOKEN` are used as is and never refreshed.

## Other notes

- `gh pr checkout <n>` switches branches. Use `gh pr diff <n>` or
  `gh pr view <n>` if you only need to read.
- `gh pr checkout <n> --worktree <path>` checks the PR out into a git worktree
  at `<path>` instead of switching the current branch.
- `gh issue develop <n> --checkout` creates a linked branch for the issue and
  checks it out. Add `--worktree <path>` to check that branch out into a git
  worktree at `<path>` instead of switching the current branch;
  `--worktree` requires `--checkout`, cannot be blank, and cannot be combined
  with `--list`.
- `NO_COLOR`, `CLICOLOR_FORCE`, and `GH_FORCE_TTY` are honored. Set
  `GH_FORCE_TTY=1` if you want TTY-style output (colors, tables, the
  pager, interactivity) inside an agent harness; leave it unset unless needed.
