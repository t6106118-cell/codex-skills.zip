# Runtime provisioning

This file documents the scc runtime used by the `scc` skill. Keep repository
measurement procedure in `SKILL.md`; use this file for installation,
verification, and upgrades.

## Source and installed state

- Upstream: `https://github.com/boyter/scc`
- Nova version: official release/tag `v4.1.0`, installed from the official release asset on 2026-11-02.
- Asset: `scc_Linux_x86_64.tar.gz`.
- Asset SHA-256:
  `c7328436d3027f4357d3d7853f7dc3ac2bbcb4ca08f1adad91a27c593884079b`.
- Root: `~/.local/opt/fedora44-tools/scc/4.1.0/` containing `scc`, `README.md`,
  and `LICENSE`.
- PATH: `~/.local/bin/scc` points to the versioned executable.
- The superseded 4.0.0 root was removed after promotion. No new binary hash or runtime smoke test was collected.

The installed command is a stripped static Linux x86-64 Go executable. It is
not RPM-owned. The guide targets the installed 4.1.0 release; historical 4.0.0 checks were not rerun for this upgrade;
upstream can have newer releases without changing nova's recorded state.

## Install

Download the exact official asset, verify the upstream-published digest, and
inspect archive member paths before extraction:

```bash
curl --fail --location --output /tmp/scc_Linux_x86_64.tar.gz \
  https://github.com/boyter/scc/releases/download/v4.1.0/scc_Linux_x86_64.tar.gz
printf '%s  %s\n' \
  c7328436d3027f4357d3d7853f7dc3ac2bbcb4ca08f1adad91a27c593884079b \
  /tmp/scc_Linux_x86_64.tar.gz | sha256sum --check
tar -tzf /tmp/scc_Linux_x86_64.tar.gz
install -d "$HOME/.local/opt/fedora44-tools/scc/4.1.0" "$HOME/.local/bin"
tar -xzf /tmp/scc_Linux_x86_64.tar.gz \
  -C "$HOME/.local/opt/fedora44-tools/scc/4.1.0"
ln -s "$HOME/.local/opt/fedora44-tools/scc/4.1.0/scc" \
  "$HOME/.local/bin/scc"
```

The expected archive contains only `scc`, `README.md`, and `LICENSE`. Use the
asset matching the target OS and architecture, adapt `fedora44-tools` to the
host convention, and inspect existing roots and links before changing them.
Ensure `~/.local/bin` is already on PATH. Building from source is unnecessary
for this baseline; if required, pin the same tag/commit and record the Go
toolchain because the resulting binary hash can differ.

## Operation and optional MCP

Use the CLI directly for repository measurements. Consult SKILL.md and the
command guide for the requested output. No post-install smoke matrix is
required by default; use an operation's actual error to guide troubleshooting.

MCP is optional process-local stdio through `scc --mcp`. It speaks JSON-RPC;
initialize it and read its returned tool schemas before using those tools.
Only register a persistent server when the task needs one. Preserve existing
server configuration and use the selected Codex home's supported MCP settings.
A saved entry does not establish that a process is running.

## Upgrade or rebuild

Use the official release asset for the host architecture and the package's
normal integrity checks. Install into a versioned root, promote the command
link after the install succeeds, and remove the superseded root. Preserve
user data and customizations directly; keep no rollback installation. Record
the source/version, asset digest, active path and actual installation result.
Run additional checks only when requested or needed to resolve an actual error.
