---
name: create-formal-verification-skill
description: Build a project-local Codex skill and a repeatable formal check for a specific software invariant, race, or state machine. Use when the task calls for durable model checking or code-level verification. Use maintain-formal-verification-skill for existing checks.
license: MIT
metadata:
  adapted-from: cursor/plugins/pstack/skills/create-formal-verification-skill
  upstream-version: "0.15.43"
---

# Create a formal verification skill

Start with the named behavior and state the property in the project's terms.
Trace the real entry point, state, writers, relevant boundaries, and failure
path. Choose one consequential property when the user delegates target choice.
Record what harm a violation causes and what the proposed check must cover.

## Build the check

- Choose a model checker for relevant interleavings and state transitions. The installed `statechart` skill can check and explain bounded TLA+ models using the workstation's Java and TLC. Use a code-level verifier if the claim concerns the implementation for every input within the tool's scope. Reuse a suitable project toolchain when available.
- Map model actions and atomic steps to the actual code. Record assumptions, bounds, and excluded behavior. Preserve the property's meaning when a counterexample appears. Trace it through the actual code before calling it an implementation bug.
- Use the project's existing dependency convention and record the exact command, inputs, working directory, and tool version. Generated-input tests can provide useful fallback evidence when only that route is available. Describe the evidence according to what ran.
- When execution is authorized, run the check as the next agent would. Use a known failing case when it can establish that the check detects the intended violation. Keep any deliberate break in an isolated scratch copy and retain the real result.

## Leave a runnable handoff

Follow [skill-creator](../.system/skill-creator/SKILL.md). Use the project's
established Codex skill directory or `.agents/skills/<name>/` by default.
Record the property, covered code and triggers, model or harness paths, how to
run the check, how to read failures, and what the check establishes at its
stated bounds. Put the coverage and last confirmed code revision in the
project's maintained record. Advance it only after establishing correspondence.
Use [maintain-formal-verification-skill](../maintain-formal-verification-skill/SKILL.md)
when that code changes. Report the result and how to invoke the generated skill.

Adapted from PStack 0.15.43. See [LICENSE](LICENSE).
