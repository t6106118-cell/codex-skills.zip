---
name: remotion-license
description: Find Remotion license information, FAQs, terms, and where to buy a license.
version: 4.0.545
---

# Remotion License

For questions about Remotion licensing, read the relevant resource:

- [License](https://www.remotion.dev/docs/license.md)
- [License FAQ](https://www.remotion.dev/docs/license/faq.md)
- [Terms and Conditions](https://www.remotion.dev/docs/terms.md)

See [License & Pricing](https://www.remotion.dev/docs/license/pricing) to buy a license.
