---
name: maintain-verification-skill
description: Reconcile an existing project-local app verification skill with the real UI, CLI, or API. Use when its launch steps, selectors, commands, or feature coverage are stale. Use create-verification-skill for new workflows and maintain-formal-verification-skill for models or proofs.
license: MIT
metadata:
  adapted-from: cursor/plugins/pstack/skills/maintain-verification-skill
  upstream-version: "0.15.43"
---

# Maintain a verification skill

Find the existing workflow named by the user or the project's instructions.
Follow its scope and read its entrypoint, relevant coverage map, and helpers.
Use the source, configured runtime, and current project paths to identify
which launch, drive, output, and cleanup steps might have drifted.

- Compare affected features, commands, or selectors to the current app. Check for duplicated or dangling instructions and for missing coverage with a concrete user-facing entry point. Keep the feature map small enough to maintain.
- When a live pass is authorized and resolves uncertainty, exercise the affected behavior through the skill's documented workflow. Reuse the project's normal launch model, retain requested evidence, and clean up the processes and test state this pass created.
- Distinguish documentation drift, a helper that fails to reach working behavior, an application regression, and a missing prerequisite. A stale selector can be repaired in the skill. An unexpected application result calls for evidence and reporting within the task's scope.
- Update only the relevant instructions, coverage, and skill-owned helpers. Preserve expectations backed by the application contract. Use the real files, selectors, commands, and prerequisites.

Report the changed paths, affected coverage, observed result, and any remaining
gap. Say whether each material conclusion came from source inspection or a live
run. Follow the user's existing scope for product fixes and repository actions.

Adapted from PStack 0.15.43. See [LICENSE](LICENSE).
