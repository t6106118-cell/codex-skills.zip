---
name: correct
description: Prevent a demonstrated recurring coding or agent mistake in a named project by fixing the structure or enforcement that allows it. Use for repeated ignores of an invariant, recurrent review corrections, or requests to prevent the same class of failure.
license: MIT
metadata:
  adapted-from: cursor/plugins/pstack/skills/correct
  upstream-version: "0.15.43"
---

# Correct a recurring mistake

Identify the repeated outcome and the rule it violates. Start with the user's
examples, relevant code, commits, reverts, or review evidence. Group examples
only when they share a cause. Use [recall](../recall/SKILL.md) for a specific
missing historical fact when a broader search is needed to establish it.

## Prevent it at the source

Choose the smallest change that would prevent the observed failure along its real path:

- Give state a clear owner, provide a single supported call path, or remove a superseded path that callers keep copying.
- Encode the invariant in types or boundary validation when that is where it can be enforced.
- Use an existing lint or test path when the behavior requires a check. Make failures identify the concrete problem and the supported action.
- Use local instructions for judgment calls that depend on context.

Apply the selected fix when authorized. If a check is appropriate for a
changed behavior, use a real past example to show what the check catches within
the user's verification scope. Follow project instructions for commits and
external actions. Record a stable rule and its enforcement in an existing
project record when it will help future maintenance.

Report the observed pattern, its cause, what now prevents it, and any material
limit. Use [reflect](../reflect/SKILL.md) for a broader retrospective on the
quality of a completed session or its skill guidance.

Adapted from PStack 0.15.43. See [LICENSE](LICENSE).
