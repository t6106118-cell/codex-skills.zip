# Install personal Codex skills on Fedora 43

This ZIP contains 61 personal skills under `skills/`, including their
documentation, scripts, assets, and lockfiles. Install them as the user who
runs Codex on the server.

From the directory containing the ZIP, run:

```bash
(
    set -e
    skill_stage=$(mktemp -d)
    trap 'rm -rf -- "$skill_stage"' EXIT
    skill_root="${CODEX_HOME:-$HOME/.codex}/skills"
    unzip -q codex-skills-fedora43-server.zip -d "$skill_stage"
    mkdir -p "$skill_root"
    cp -a "$skill_stage/skills/." "$skill_root/"
)
```

If a same-named skill already contains local edits, reconcile those files before
copying. Keep Codex's existing system skills and open a fresh Codex session
after the copy.

## Runtimes on the server

Read a skill's `RUNTIME.md` when present before rebuilding its dependencies.
Re-create Python environments and npm or Bun dependencies using the included
manifests and lockfiles. The archive includes bundled tools such as Statechart's
TLC jar. Use the server's paths and package versions for external runtimes.
Browser-based workflows need a compatible headless browser or a reachable
browser connection. Set up plugin connections, MCP servers, and sign-ins on
the server when the requested workflow needs them.
