# Build the reusable Codex projects on Fedora 43

Build these five projects under the server user's `~/projects`. The archive's
`projects/` directory contains the workstation's manifests, lockfiles, starter
sources, and a Gephi Lite source snapshot. The target agent owns installation
and the server's documentation.

| Project | What to use it for |
| --- | --- |
| data-analysis-template | Scientific Python, Jupyter, plotting, data exchange, and network analysis |
| javascript-graphics-template | D3, React, SVG charts, browser animations, standalone HTML and image processing |
| animation-rendering | HyperFrames and Remotion video, Playwright frame capture, and Manim/Typst |
| web-retrieval | HTTP retrieval, HTML extraction, Scrapy, and Playwright |
| gephi-lite | Local graph visualization and access to the Gephi Lite workspaces |

## Install and build

1. Extract to a staging directory. Copy the five project directories under
   the server's `~/projects`, merging with any existing project rather than
   overwriting user changes. Read each project's `AGENTS.md` and
   `CURRENT_STATE.md` before building it. The bundled current-state files
   describe a source handoff. Record installed versions and actual outcomes
   in those files as you work.

2. Use a single Node.js 24 runtime and npm for the three Node projects. Use
   `uv` for the Python environments. Reuse suitable software already on the
   server, including FFmpeg and headless Chrome or Chromium. Resolve any
   missing system libraries using Fedora 43 packages or the supported
   user-local runtime. Install Cairo and Pango development dependencies for
   Manim as needed, and LaTeX plus `dvisvgm` for `MathTex`.

3. Restore the environments from the included locks:

   ```bash
   uv sync --project "$HOME/projects/data-analysis-template" --locked --python 3.15
   uv sync --project "$HOME/projects/web-retrieval" --locked --python 3.14
   uv sync --project "$HOME/projects/animation-rendering/manim" --locked --python 3.14

   npm ci --prefix "$HOME/projects/javascript-graphics-template"
   npm ci --prefix "$HOME/projects/animation-rendering"
   npm ci --prefix "$HOME/projects/gephi-lite"
   npm --prefix "$HOME/projects/gephi-lite" run build
   ```

   Use a uv-managed interpreter if the server's system Python is a different
   version. If a locked interpreter or dependency is unavailable for the host,
   diagnose the actual failure, make the smallest project-local adjustment
   that restores capability, and record any lockfile or version change.

4. Provision the browsers for the workflows that use them. In
   `~/projects/animation-rendering`, run
   `npm exec -- playwright install --only-shell chromium` and
   `HYPERFRAMES_NO_TELEMETRY=1 npm exec -- hyperframes browser ensure`.
   Point Remotion and Kaleido at the actual compatible browser on the server.
   The retrieval project's `scrapy_settings.py` uses the Chrome channel.
   Keep it when Google Chrome is installed. For a Chromium-only server,
   configure the equivalent Playwright launch path or install the browser
   version selected by that project's Playwright.

5. Replace the `/home/nova/projects/javascript-graphics-template` literal in
   `javascript-graphics-template/templates/html-page/build.cjs` and
   `javascript-graphics-template/templates/html-page/input.css` with the
   actual absolute path. Update affected README examples to match the server.
   Review the animation and retrieval launch instructions for the real
   browser executable and home path. Keep task sources and generated outputs
   in task workspaces.

6. For Gephi Lite, this is the working source at upstream commit
   `9570b9cb8bb0fcd9b0912bc68601a13cbaad07ca` with the workstation's local changes
   applied. [Upstream](https://github.com/gephi/gephi-lite/tree/9570b9cb8bb0fcd9b0912bc68601a13cbaad07ca)
   To preview on the server, run from its project directory:

   ```bash
   npm run serve --workspace=@gephi/gephi-lite -- --host 127.0.0.1
   ```

   The preview route is `http://127.0.0.1:4173/gephi-lite/`. Use SSH port
   forwarding when viewing the loopback preview from another machine.

## Update the server's global Codex instructions

Merge a brief **Local capabilities and environments** section into
`~/.codex/AGENTS.md`, or the equivalent global file if the server uses a custom
`CODEX_HOME`. Preserve any existing instructions. List the five projects'
actual absolute paths and one line each about what to use them for. Include
the server's normal `uv run --project …` path for Python and the shared
`NODE_PATH=…/node_modules node …` path for standalone CommonJS. Direct readers
to each project's README for commands and to its CURRENT_STATE.md for current
status. Use the results of installation and build to describe what is ready.

End with the installed project paths, any server-specific dependency changes,
and the updated global AGENTS.md location.
