# Working instructions

Read [CURRENT_STATE.md](CURRENT_STATE.md) before making changes in this environment.
Keep dependencies and lockfiles in this project. Keep task assets, composition
sources and rendered outputs in task workspaces. See README.md for launch and
restore procedures.
