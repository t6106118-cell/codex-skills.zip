# Animation rendering on Fedora

Use the [shared graphics environment](../javascript-graphics-template/README.md)
for SVG authoring and browser motion. Use this environment to render compositions
to frames or video. Keep source, assets and output in the task directory.

| Job | Tool |
| --- | --- |
| HTML, CSS or SVG motion exported to MP4 | HyperFrames 0.9.66 and its managed Chrome Headless Shell |
| Custom frame-by-frame website capture | Playwright 1.65.1 and FFmpeg. Drive the scene by frame number or timestamp. |
| Video built from React components | Remotion 4.0.545 and system Google Chrome |
| Equations, geometry and narrated math scenes | Manim Community 0.22.1, Python 3.14, TeX and Typst |
| 3D scenes and camera animation | Blender and its Python API |
| SVG cleanup and PNG or PDF export | Inkscape. Inter is available to desktop and browser renderers. |

## Start a task

For HTML-to-video work, set the launcher path and run commands from the task
directory. `init` creates a composition project. For a finished composition,
run `render` from its directory.

```bash
hf="$HOME/.codex/skills/hyperframes/scripts/plugin-cli.mjs"
node "$hf" init my-video --skip-skills
cd my-video
node "$hf" render --quality draft -o preview.mp4
```

The launcher uses the locked local CLI and disables telemetry. See the upstream
[quickstart](https://hyperframes.heygen.com/quickstart) for composition syntax.

For Remotion, give each composition project its own `remotion`, `@remotion/cli`,
`react`, and `react-dom` dependencies so the bundler can resolve imports next
to the source. Match the Remotion versions in this environment. From a configured
project with a registered `MyVideo` composition, run:

```bash
npm exec -- remotion render src/index.ts MyVideo out/video.mp4 \
  --browser-executable=/usr/bin/google-chrome
```

See the [Remotion CLI guide](https://www.remotion.dev/docs/cli/render) and
[license terms](https://www.remotion.dev/license).

Run task-owned Playwright CommonJS with
`NODE_PATH="$HOME/projects/animation-rendering/node_modules" node capture.cjs`.
For native ESM projects, declare Playwright as a project dependency. Playwright
uses its Ubuntu 24.04 compatibility build on Fedora. The installed system Chrome
is also available through `chromium.launch({ channel: 'chrome' })`.

Run Manim from the task directory:

```bash
uv run --project "$HOME/projects/animation-rendering/manim" --locked \
  manim -ql scene.py MyScene
```

`MathTex` uses system LaTeX and `dvisvgm`. Typst support is installed in the
Python environment. See the [Manim documentation](https://docs.manim.community/en/stable/).

Inkscape can export a finished SVG with `inkscape chart.svg --export-filename=chart.pdf`.
Blender can render a configured animation with `blender --background scene.blend --render-anim`.
Run both from the task directory. Blender writes to the output path saved in
the scene. [Inkscape CLI](https://wiki.inkscape.org/wiki/Using_the_Command_Line) · [Blender CLI](https://docs.blender.org/manual/en/latest/advanced/command_line/render.html)

## Frame timing

For custom browser capture, give the scene an explicit `seek(seconds)` and render
frame `n` at `n / fps`. Load fonts and images before capture and seed randomness
that affects the scene. Use CSS-pixel screenshots when the viewport specifies
the required output size. For a loop, match the scene state at both ends and
capture the distinct frames before the endpoint. Keep effects, labels, and
motion on the same timeline. [Playwright screenshots](https://playwright.dev/docs/api/class-page#page-screenshot) ·
[Frame-by-frame Canvas example](https://github.com/klsoen/opus-js-animations#every-frame-is-seek-t)

## Restore the runtimes

On Fedora 45, install these packages alongside Node.js 22 or newer, npm, uv,
the existing FFmpeg and Google Chrome:

```bash
sudo dnf install inkscape blender rsms-inter-fonts python3.14 python3.14-devel \
  cairo-devel pango-devel pkgconf-pkg-config texlive-latex tex-preview \
  texlive-babel-english texlive-amsmath texlive-amsfonts texlive-standalone texlive-dvisvgm

cd "$HOME/projects/animation-rendering"
npm ci
npm exec -- playwright install --only-shell chromium
HYPERFRAMES_NO_TELEMETRY=1 npm exec -- hyperframes browser ensure
uv sync --project manim --locked --python /usr/bin/python3.14 --no-python-downloads
```

`package-lock.json` pins the video tools and `manim/uv.lock` pins the math
environment. `package.json` approves only the two esbuild install-hook versions
needed by the locked video stack.
