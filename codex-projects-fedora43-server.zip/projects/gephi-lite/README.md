# Gephi Lite

Gephi Lite is a free and open-source web application to visualize and explore networks and graphs. It is a web-based, lighter version of [Gephi](https://gephi.org/). You can try it here:

**[gephi.org/gephi-lite](https://gephi.org/gephi-lite)**

It is currently under active developments, so features can evolve quite quickly. Feel free to report bugs or ask for new features in the [issues board](https://github.com/gephi/gephi-lite/issues).

You can read more about the intent of this project on the [Gephi blog](https://gephi.wordpress.com/2022/11/15/gephi-lite/).

## License

Gephi Lite source code is distributed under the [GNU General Public License v3](http://www.gnu.org/licenses/gpl.html).

## Repository structure

The codebase is organized as a [monorepo](https://en.wikipedia.org/wiki/Monorepo):

- **[packages/gephi-lite](packages/gephi-lite)** contains Gephi Lite application code
- **[packages/sdk](packages/sdk) ([`@gephi/gephi-lite-sdk` on npm](https://www.npmjs.com/package/@gephi/gephi-lite-sdk))** contains core Gephi Lite types and utilities.
- **[packages/broadcast](packages/broadcast) ([`@gephi/gephi-lite-broadcast` on npm](https://www.npmjs.com/package/@gephi/gephi-lite-broadcast))** provides TypeScript helpers to control a Gephi Lite instance from another tab or frame.

## Run locally

Gephi Lite is a web application, written using [TypeScript](https://www.typescriptlang.org/) and [React](https://react.dev/). The styles are written using [SASS](https://sass-lang.com/), and are based on [Bootstrap v5](https://getbootstrap.com/).

Gephi Lite uses [sigma.js](https://www.sigmajs.org/) for graph rendering, and [graphology](https://graphology.github.io/) as the graph model as well as for graph algorithms. It is built using [Vite](https://vitejs.dev/).

Use [Node.js 24](https://nodejs.org/en) and npm. Run `npm ci` from the repository root to install the locked dependencies.

Now, in the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:5173/gephi-lite](http://localhost:5173/gephi-lite) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `npm test`

Runs the Vitest browser suites once. Install the locked Chromium headless shell with `npm exec -- playwright install --only-shell chromium` before the first run.

Run `npm run test:e2e` to build the app, start a loopback preview, and run the Playwright graph import and screenshot tests. When a visual change is intentional, review the screenshot differences and update the affected baselines with Playwright's `--update-snapshots` option.

### `npm run build`

Builds the SDK and broadcast library, then writes the app and workspace schema to `packages/gephi-lite/build/`.

Run `npm run serve --workspace=@gephi/gephi-lite` to preview the build at `http://localhost:4173/gephi-lite/`.

The publishing configuration in `lerna.json` is available separately through `npm exec --yes --package=lerna@10.1.1 -- lerna`. Normal installation and development use npm workspaces.

## Docker

Docker allows building and running Gephi lite in a controlled environment without installing npm and project dependencies on your host system.

### Docker compose for development

The docker compose provided in this repository runs Gephi Lite directly from sources and is designed for **local development** not for production.

Make sure you have a fresh version of [Docker](https://docs.docker.com/get-docker/) and [Docker Compose](https://docs.docker.com/compose/install/linux/) plugin. Effective July 2023 Compose is now integrated into all current Docker Desktop versions.

#### `docker compose up`

Starts Gephi Lite in development mode at http://localhost:5173/gephi-lite/

#### `docker compose down`

Stops container and frees all the resources obtained by the container.

### Dockerfile for production

The Dockerfile provided in this repository is designed for **production**.
The application is build and then served by nginx, which its port is exposed by docker

- Build the project :

```
$> export BASE_URL="./"
$> npm run build
```

- Build the image : `docker build -f Dockerfile -t gephi-lite .`
- Create & run a container : `docker run -p 80:80 gephi-lite`

### Any custom `npm` command

Run `docker compose run --entrypoint sh gephi-lite` and you'll get into the shell where you can run all the `npm` commands from above

## Deploy the application

To allow users to synchronize their data with GitHub, Gephi Lite needs a reverse proxy to avoid CORS issues. The [Vite development server](packages/gephi-lite/vite.config.mts) proxies these requests locally.

To deploy the application, you need to define the env variable `VITE_GITHUB_PROXY` before building it, by following those steps:

```
$> VITE_GITHUB_PROXY=mydomain.for.github.auth.proxy.com
$> npm install
$> npm run build
```

On [gephi.org/gephi-lite](https://gephi.org/gephi-lite) we use this setting : `VITE_GITHUB_PROXY: "https://githubapi.gephi.org"`.

Then on our server, we configured NGINX with this following settings:

```nginx
server {
    listen 443 ssl;
    server_name githubapi.gephi.org;

    ssl_certificate /etc/letsencrypt/live/githubapi.gephi.org/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/githubapi.gephi.org/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;

   location /login {
     add_header Access-Control-Allow-Origin "https://gephi.org";
     add_header Access-Control-Allow-Methods "GET, POST, OPTIONS";
     add_header Access-Control-Allow-Headers "Origin, X-Requested-With, Content-Type, Accept, user-agent";
     if ($request_method = OPTIONS) {
        return 204;
     }
     proxy_pass https://github.com/login;
   }

   location / {
     return 404;
   }
}
```

PS: On this configuration you should change the `server_name` with its ssl configuration, as well as the `add_header Access-Control-Allow-Origin` value.
