# Current state

Source files supplied for the Fedora 43 server setup. See the top-level SETUP.md in the transfer archive.

Install the npm workspaces and build Gephi Lite.
