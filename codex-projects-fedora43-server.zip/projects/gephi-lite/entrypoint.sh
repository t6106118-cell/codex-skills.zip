#!/bin/sh
set -eu
cd /code
npm ci
exec npm start
