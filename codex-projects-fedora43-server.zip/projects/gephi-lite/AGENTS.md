# Local working instructions
Read CURRENT_STATE.md before substantive work in this checkout.
Use the repository's npm workspaces and lockfile. Keep dependencies local to this checkout.
