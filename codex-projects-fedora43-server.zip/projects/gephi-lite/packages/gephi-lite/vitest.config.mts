import UnpluginTypia from "@ryoppippi/unplugin-typia/vite";
import { playwright } from "@vitest/browser-playwright";
import { defineConfig } from "vitest/config";

export default defineConfig({
  plugins: [UnpluginTypia({})],
  test: {
    globals: true,
    browser: {
      provider: playwright(),
      instances: [
        {
          browser: "chromium",
        },
      ],
      enabled: true,
      headless: true,
    },
  },
  optimizeDeps: {
    exclude: ["chromium-bidi"],
    include: [
      "react/jsx-dev-runtime",
      "typia/lib/internal/_accessExpressionAsString.js",
      "typia/lib/internal/_assertGuard.js",
    ],
  },
});
