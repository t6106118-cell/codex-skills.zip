declare module "locale-emoji";
