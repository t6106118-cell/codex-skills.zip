import { FieldModel, ItemType, gephiLiteParse, gephiLiteStringify } from "@gephi/gephi-lite-sdk";

import { DEFAULT_LOCALE } from "../../locales/LOCALES";
import { localStorage } from "../../utils/storage";
import { Preferences } from "./types";

export function getEmptyPreferences(): Preferences {
  return {
    colors: { partition: [], ranking: [] },
    // default is the local detected by i18n
    locale: DEFAULT_LOCALE,
    theme: "auto",
  };
}

export function getCurrentPreferences(): Preferences {
  try {
    const rawPreferences = localStorage.getItem("preferences");
    const preferences = rawPreferences ? parsePreferences(rawPreferences) : null;
    return { ...getEmptyPreferences(), ...preferences };
  } catch (e) {
    console.error(e);
    return getEmptyPreferences();
  }
}

/**
 * Preferences lifecycle helpers (state serialization / deserialization):
 */
export function serializePreferences(preferences: Preferences): string {
  return gephiLiteStringify(preferences);
}

export function parsePreferences(rawPreferences: string): Preferences | null {
  try {
    // TODO:
    // Validate the actual data
    return gephiLiteParse(rawPreferences);
  } catch (e) {
    console.error(e);
    return null;
  }
}

export function getAppliedTheme(theme: Preferences["theme"]): "light" | "dark" {
  if (theme === "auto") {
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) return "dark";
    else return "light";
  }
  return theme;
}

export function isSameField(field1: FieldModel<ItemType, boolean>, field2: FieldModel<ItemType, boolean>) {
  return field1.id === field2.id && field1.itemType === field2.itemType;
}
