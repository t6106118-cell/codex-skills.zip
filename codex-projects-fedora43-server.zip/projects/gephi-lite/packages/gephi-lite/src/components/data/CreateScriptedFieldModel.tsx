import { FieldModel, FullGraph, ItemData, ItemType, Scalar } from "@gephi/gephi-lite-sdk";
import cx from "classnames";
import { FC, useCallback, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router";

import { useFilteredGraph, useGraphDataset, useGraphDatasetActions } from "../../core/context/dataContexts";
import { graphDatasetAtom } from "../../core/graph";
import { inferFieldType } from "../../core/graph/fieldModel";
import { dataGraphToFullGraph } from "../../core/graph/utils";
import { useNotifications } from "../../core/notifications";
import { isScalar } from "../../utils/check";
import { CancelIcon, ExternalLinkIcon } from "../common-icons";
import { useFunctionEditor } from "../modals/FunctionEditor";

export type CreateScriptedFieldModelFormProps = {
  fullEditor: boolean;
  onSubmitted: () => void;
  onCancel: () => void;
  type: ItemType;
  insertAt?: { id: string; pos: "before" | "after" };
};

type ScriptedFieldModelFunction = (id: string, attributes: ItemData, index: number, graph: FullGraph) => Scalar;

const BASE_JS = {
  nodes: {
    doc: `/**
* Function that returns a new attribute value for the specified node.
*
* @param {string} id The ID of the node
* @param {GraphNode} attributes Attributes of the node
* @param {number} index The index position of the node in the graph
* @param {AbstractGraph<GraphNode, GraphEdge>} graph Graphology instance (https://graphology.github.io/)
* @returns number|string|boolean|null|undefined" The value of the new node's attribute
*/`,
    baseFn: `function addNodeAttribute(id, attributes, index, graph) {
  //
  // Your code goes here
  //
  return Math.random();
}`,
    check: (fn: ScriptedFieldModelFunction) => {
      if (!fn) throw new Error("Function is not defined");
      const fullGraph = dataGraphToFullGraph(graphDatasetAtom.get());
      const id = fullGraph.nodes()[0];
      const attributes = fullGraph.getNodeAttributes(id);
      const result = fn(id, attributes, 0, fullGraph);
      if (!isScalar(result)) throw new Error("Function must returns a number, a string, a boolean, null or undefined");
    },
  },
  edges: {
    doc: `/**
* Function that returns a new attribute value for the specified edge.
*
* @param {string} id The ID of the edge
* @param {GraphNode} attributes Attributes of the node
* @param {number} index The index position of the node in the graph
* @param {AbstractGraph<GraphNode, GraphEdge>} graph Graphology instance (https://graphology.github.io/)
* @returns number|string|boolean|null|undefined" The value of the new edge's attribute
*/`,
    baseFn: `function addEdgeAttribute(id, attributes, index, graph) {
  //
  // Your code goes here
  //
  return Math.random();
}`,
    check: (fn: ScriptedFieldModelFunction) => {
      if (!fn) throw new Error("Function is not defined");
      const fullGraph = dataGraphToFullGraph(graphDatasetAtom.get());
      const id = fullGraph.edges()[0];
      const attributes = fullGraph.getEdgeAttributes(id);
      const result = fn(id, attributes, 0, fullGraph);
      if (!isScalar(result)) throw new Error("Function must returns a number, a string, a boolean, null or undefined");
    },
  },
};

export const useCreateScriptedFieldModelForm = ({
  onCancel,
  onSubmitted,
  type,
  insertAt,
}: CreateScriptedFieldModelFormProps) => {
  const { t } = useTranslation();
  const { notify } = useNotifications();
  const dataset = useGraphDataset();
  const filteredGraph = useFilteredGraph();
  const { createFieldModel } = useGraphDatasetActions();
  const { nodeFields, edgeFields } = dataset;
  const checkFunction = useCallback(
    (fn: ScriptedFieldModelFunction) => {
      if (!fn) throw new Error("Function is not defined");

      const fullGraph = dataGraphToFullGraph(graphDatasetAtom.get());
      const id = fullGraph[type]()[0];
      const attributes = type === "nodes" ? fullGraph.getNodeAttributes(id) : fullGraph.getEdgeAttributes(id);
      const result = fn(id, attributes, 0, fullGraph);
      if (!isScalar(result)) throw new Error("Function must returns a number, a string, a boolean, null or undefined");
    },
    [type],
  );

  const [newId, setNewId] = useState<string>("");
  // TODO: Add input for scope
  const [scope, _setScope] = useState<"all" | "filtered" /* | "selected"*/>("all");

  const fields = type === "nodes" ? nodeFields : edgeFields;
  const existingField = useMemo(() => fields.find((f) => f.id === newId), [fields, newId]);
  const isFormValid = useMemo(() => !!newId && !existingField, [existingField, newId]);

  const onSubmit = useCallback(
    (script: ScriptedFieldModelFunction) => {
      try {
        let graph: FullGraph;
        switch (scope) {
          // TODO:
          // case "selected":
          //   graph = dataGraphToFullGraph(dataset, dataset);
          //   break;
          case "filtered":
            graph = dataGraphToFullGraph(dataset, filteredGraph);
            break;
          case "all":
          default:
            graph = dataGraphToFullGraph(dataset);
            // graph = dataGraphToFullGraph(graphDatasetAtom.get());
            break;
        }

        Object.freeze(graph);

        const values: Record<string, Scalar> = {};
        if (type === "nodes") {
          graph.nodes().forEach((id, index) => {
            values[id] = script(id, graph.getNodeAttributes(id), index, graph);
          });
        } else {
          graph.edges().forEach((id, index) => {
            values[id] = script(id, graph.getEdgeAttributes(id), index, graph);
          });
        }

        const valuesArray = Object.values(values);

        const fieldModel: FieldModel = {
          id: newId,
          itemType: type,
          ...inferFieldType(newId, valuesArray, valuesArray.length),
        };
        const index = insertAt
          ? fields.findIndex((f) => f.id === insertAt.id) + (insertAt.pos === "before" ? -1 : 1)
          : undefined;
        createFieldModel(fieldModel, { index, values });
        notify({
          type: "success",
          title: t(`edition.create_${type}_scripted_field`),
          message: t(`edition.create_${type}_scripted_field_success`),
        });
      } catch (e) {
        notify({
          type: "error",
          title: t(`edition.create_${type}_scripted_field`),
          message: (e as Error).message || t("error.unknown"),
        });
      }
      if (onSubmitted) onSubmitted();
    },
    [createFieldModel, dataset, fields, filteredGraph, insertAt, newId, notify, onSubmitted, scope, t, type],
  );
  const { content: editorContent, getFunction } = useFunctionEditor<ScriptedFieldModelFunction>({
    checkFunction,
    functionJsDoc: BASE_JS[type].doc,
    initialFunctionCode: BASE_JS[type].baseFn,
    title: type === "nodes" ? t("edition.create_nodes_scripted_field") : t("edition.create_edges_scripted_field"),
    description: (
      <div className="m-3">
        <p className="mb-0">
          {type === "nodes"
            ? t("edition.create_nodes_scripted_script_description")
            : t("edition.create_edges_scripted_script_description")}
        </p>
        <Link to="https://docs.gephi.org/lite/user-manual/custom-scripts" title={t("common.help")} target="_blank">
          {t("common.see-documentation")}
          <ExternalLinkIcon className="ms-1" />
        </Link>
      </div>
    ),
    onSubmit: isFormValid ? onSubmit : undefined,
    saveAndRunI18nKey: "datatable.save_and_create_column",
  });
  const submit = useCallback(() => {
    const fn = getFunction();
    if (fn && isFormValid) onSubmit(fn);
  }, [getFunction, isFormValid, onSubmit]);

  return {
    submit,
    main: (
      <div className="panel-body">
        <h2>{t(`edition.create_${type}_scripted_field`)}</h2>
        <div className="panel-block">
          <label htmlFor="column-id" className="form-label">
            {t("graph.model.field.id")}
          </label>
          <input
            required
            type="text"
            id="column-id"
            className={cx("form-control", existingField && "is-invalid")}
            value={newId}
            onChange={(e) => setNewId(e.target.value)}
          />
          {existingField && (
            <div className="invalid-feedback">
              {t(`error.form.field_already_exists`, {
                id: existingField.id,
                label: existingField.label || existingField.id,
              })}
            </div>
          )}
        </div>
        {editorContent}
      </div>
    ),
    footer: (
      <div className="panel-footer">
        <div className="gl-actions">
          <button type="button" className="gl-btn gl-btn-icon gl-btn-outline" onClick={() => onCancel()}>
            <CancelIcon />
          </button>

          <button type="submit" className="gl-btn gl-btn-fill">
            {t("datatable.create_column")}
          </button>
        </div>
      </div>
    ),
  };
};

export const CreateScriptedFieldModelForm: FC<Omit<CreateScriptedFieldModelFormProps, "fullEditor">> = (props) => {
  const { main, footer, submit: submitForm } = useCreateScriptedFieldModelForm({ ...props, fullEditor: false });

  return (
    <form className="panel-wrapper" onSubmit={submitForm}>
      {main}
      {footer}
    </form>
  );
};
