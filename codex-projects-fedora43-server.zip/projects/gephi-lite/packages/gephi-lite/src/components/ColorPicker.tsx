import { FC, useRef } from "react";
import { SketchPicker } from "react-color";
import { PresetColor } from "react-color/lib/components/sketch/Sketch";
import { useTranslation } from "react-i18next";

import { hexToRgba, rgbaToHex } from "../utils/colors";
import Tooltip, { TooltipAPI } from "./Tooltip";

export const InlineColorPicker: FC<{
  color: string | undefined;
  presetColors?: PresetColor[];
  onChange: (color: string | undefined) => void;
}> = ({ color, onChange, presetColors }) => {
  return (
    <SketchPicker
      color={color ? hexToRgba(color) : undefined}
      onChange={(color, e) => {
        onChange(rgbaToHex(color.rgb));
        // To avoid text selection while draggin
        if (e.stopPropagation) e.stopPropagation();
        if (e.preventDefault) e.preventDefault();
      }}
      presetColors={presetColors}
      styles={{
        default: {
          picker: {
            boxShadow: "none",
            padding: 0,
          },
        },
      }}
    />
  );
};

const ColorPicker: FC<
  (
    | { color: string | undefined; onChange: (color: string | undefined) => void; clearable: true }
    | { color: string; onChange: (color: string) => void; clearable?: false }
  ) & { className?: string; presetColors?: PresetColor[] }
> = ({ color, onChange, clearable, className, presetColors }) => {
  const { t } = useTranslation();
  const tooltipRef = useRef<TooltipAPI>(null);

  return (
    <Tooltip ref={tooltipRef} attachment="top middle" targetAttachment="bottom middle" targetClassName={className}>
      <button
        type="button"
        className="gl-btn square border border-black border-2"
        style={{ background: color || "#ffffff" }}
      >
        {/* icon container which can hold a symbol depending on targetClassName. It's used for palette missing color cases */}
        <span className="icon-container"></span>
      </button>
      <div className="custom-color-picker gl-border">
        <InlineColorPicker onChange={onChange} color={color} presetColors={presetColors} />
        <div className="text-end gl-gap-1 d-flex justify-content-end">
          {clearable && (
            <button className="gl-btn gl-btn-outline" onClick={() => onChange(undefined)}>
              {t("common.clear")}
            </button>
          )}
          <button className="gl-btn gl-btn-fill" onClick={() => tooltipRef.current?.close()}>
            {t("common.close")}
          </button>
        </div>
      </div>
    </Tooltip>
  );
};

export default ColorPicker;
