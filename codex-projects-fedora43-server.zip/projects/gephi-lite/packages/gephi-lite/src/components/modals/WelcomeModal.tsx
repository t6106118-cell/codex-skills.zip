import { FC } from "react";
import { useTranslation } from "react-i18next";

import GephiLiteReversedLogo from "../../assets/gephi-lite-logo-reversed.svg?react";
import GephiLiteLogo from "../../assets/gephi-lite-logo.svg?react";
import { useFile, useFileActions, useGraphDatasetActions, usePreferences } from "../../core/context/dataContexts";
import { errorToCode, errorToString } from "../../core/errors";
import { useModal } from "../../core/modals";
import { ModalProps } from "../../core/modals/types";
import { useNotifications } from "../../core/notifications";
import { getAppliedTheme } from "../../core/preferences/utils";
import { useVersion } from "../../core/version/useVersion";
import { Loader } from "../Loader";
import { DonateIcon, GitHubIcon, NewsIcon } from "../common-icons";
import { Modal } from "../modals";
import { OpenModal } from "./open/OpenModal";

const SAMPLES = ["Les Miserables.json", "Java.gexf", "Power Grid.gexf", "airports.json"];

export const WelcomeModal: FC<ModalProps<unknown>> = ({ cancel, submit }) => {
  const { t } = useTranslation();
  const { current, latest } = useVersion();
  const { openModal } = useModal();
  const { notify } = useNotifications();
  const { theme } = usePreferences();
  const { resetGraph } = useGraphDatasetActions();
  const {
    status: { type: fileStateType },
  } = useFile();
  const { open } = useFileActions();

  return (
    <Modal showHeader={false} onClose={fileStateType === "loading" ? undefined : () => cancel()} className="modal-lg">
      <div className="row position-relative align-items-end mb-5 mt-4">
        <div className="col-12 col-sm-6 d-flex flex-column align-items-center gl-gap-1 mb-5 mb-sm-0">
          {getAppliedTheme(theme) === "light" ? (
            <GephiLiteLogo className="mb-3 gl-px-2 w-33" />
          ) : (
            <GephiLiteReversedLogo className="mb-3 gl-px-2 w-33" />
          )}
          <h2 className="gl-px-2 gl-heading-2 text-center mb-0">{t("welcome.title")}</h2>
          <div>
            v{current.version} -{" "}
            <a rel="noreferrer" target="_blank" href="https://github.com/gephi/gephi-lite/blob/main/CHANGELOG.md">
              changelog
            </a>
          </div>
          {latest && latest.type === "version" && (
            <div className="mt-2">
              <NewsIcon className="gl-icon-size-text gl-mx-1" />
              {t("welcome.new_version_available")}{" "}
              <a href={latest.url} title={`Gephi-Lite v${latest.version}`}>
                {t("common.here")}
              </a>
            </div>
          )}
          <div className="d-flex flex-wrap align-items-center gl-gap-2 justify-content-center mt-3">
            <a rel="noreferrer" target="_blank" className="gl-btn gl-btn-outline" href="https://gephi.org/lite">
              {t("welcome.website")}
            </a>
            <a rel="noreferrer" target="_blank" className="gl-btn gl-btn-outline" href="https://docs.gephi.org/lite">
              {t("welcome.documentation")}
            </a>
          </div>
          <div className="d-flex flex-wrap align-items-center gl-gap-2 justify-content-center">
            <a
              rel="noreferrer"
              target="_blank"
              className="gl-btn gl-btn-icon gl-btn-fill"
              href="https://opencollective.com/gephi/donate?tags=gephi-lite&interval=oneTime&amount=5&contributeAs=me"
            >
              <DonateIcon /> {t("welcome.donate")}
            </a>
            <a
              rel="noreferrer"
              target="_blank"
              className="gl-btn gl-btn-icon gl-btn-outline"
              href="https://github.com/gephi/gephi-lite"
            >
              <GitHubIcon />
            </a>
          </div>
        </div>
        <div className="col-12 col-sm-6 px-5">
          <h3 className="gl-px-2 gl-heading-3">{t("welcome.open_graph")}</h3>
          <ul className="list-unstyled mb-0 d-flex flex-column">
            <li className="mb-1">
              <button
                className="gl-btn text-start"
                title={t(`graph.open.local.title`)}
                onClick={() => {
                  openModal({ component: OpenModal, arguments: { initialOpenedTab: "local" } });
                }}
              >
                {t(`graph.open.local.title`)}
              </button>
            </li>
            <li className="mb-1">
              <button
                className="gl-btn text-start"
                title={t(`graph.open.github.title`)}
                onClick={() => {
                  openModal({ component: OpenModal, arguments: { initialOpenedTab: "github" } });
                }}
              >
                {t(`graph.open.github.title`)}
              </button>
            </li>
            <li className="mb-1">
              <button
                className="gl-btn text-start"
                title={t(`graph.open.github.title`)}
                onClick={() => {
                  resetGraph();
                  submit({});
                }}
              >
                {t(`graph.open.new.title`)}
              </button>
            </li>
          </ul>
          <br />
          <h3 className="gl-px-2 gl-heading-3">{t("welcome.samples")}</h3>
          <ul className="list-unstyled mb-0 d-flex flex-column">
            {SAMPLES.map((sample) => (
              <li key={sample}>
                <button
                  className="gl-btn text-start"
                  onClick={async () => {
                    try {
                      const { forced } = await open(
                        { type: "remote", url: `${import.meta.env.BASE_URL}samples/${sample}`, filename: sample },
                        { force: "fallback" },
                      );
                      notify(
                        forced
                          ? { type: "warning", message: t("graph.open.force_notification") }
                          : {
                              type: "success",
                              message: t("graph.open.remote.success", { filename: sample }),
                              title: t("gephi-lite.title"),
                            },
                      );
                      submit({});
                    } catch (e) {
                      console.error(e);
                      notify({
                        type: "error",
                        message: errorToCode(e) ? errorToString(e) : t("graph.open.remote.error"),
                        title: t("gephi-lite.title"),
                      });
                    }
                  }}
                >
                  {sample}
                </button>
              </li>
            ))}
          </ul>
        </div>
        {fileStateType === "loading" && <Loader />}
      </div>
    </Modal>
  );
};
