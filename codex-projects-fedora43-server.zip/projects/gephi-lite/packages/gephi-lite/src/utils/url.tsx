import { Fragment } from "react";

import linkify, { prettifyURL } from "./linkify";

/**
 * Given an url, returns the filename
 */
export function extractFilename(url: string): string {
  return url.split("/").pop() || url;
}

export function LinkifiedText({ value }: { value: string }) {
  const matches = linkify.match(value);
  if (!matches) return <>{value}</>;

  let offset = 0;
  const links = matches.map(({ index, lastIndex, url, text }) => {
    const precedingText = value.slice(offset, index);
    offset = lastIndex;
    return (
      <Fragment key={index}>
        {precedingText}
        <a href={url} target="_blank" rel="noreferrer">
          {prettifyURL(text)}
        </a>
      </Fragment>
    );
  });
  return (
    <>
      {links}
      {value.slice(offset)}
    </>
  );
}
