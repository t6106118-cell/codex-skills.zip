import { expect, test } from "@playwright/test";

const FILES = ["Java.gexf", "Les Miserables.gexf", "Power Grid.gexf", "airlines.graphml"];

FILES.forEach((file) => {
  test(`Loading '${file}' should work`, async ({ page }) => {
    const params = new URLSearchParams({ file: `./samples/${file}` });
    await page.goto(`?${params}`);

    // Wait for the graph to be fully loaded
    await expect(page).toHaveTitle(`Gephi Lite - ${file}`, { timeout: 30000 });

    // Check the screenshot
    await expect(page).toHaveScreenshot(`${file}.png`, { maxDiffPixelRatio: 0.01 });
  });
});
