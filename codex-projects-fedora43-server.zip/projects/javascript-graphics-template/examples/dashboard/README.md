# Dashboard example

Copy the HTML starter into a task folder, replace its `app.jsx` with this file,
and run the task's `build.cjs`; see `../README.md` for commands.

Uses React state with daisyUI stat cards, inputs, table, badges and buttons.
Search and status filters affect displayed rows and exported JSON. Summary cards
show totals across all rows. Mark done updates the local state and totals; no
server or persistence is involved, and reloading resets the illustrative data.

Replace `initial` with task records. Preserve stable row IDs and update status
options when changing the record format. Empty search/filter results are explicit.
