import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {downloadJson} from './export.js';

const initial = [
  {id:1,name:'Research summary',owner:'Ada',status:'In progress'},
  {id:2,name:'Network map',owner:'Maya',status:'Ready'},
  {id:3,name:'Quarterly chart',owner:'Lin',status:'In progress'},
  {id:4,name:'Project notes',owner:'Noor',status:'Done'},
  {id:5,name:'Dataset review',owner:'Sam',status:'Ready'},
];
function App() {
  const [rows,setRows] = useState(initial), [query,setQuery] = useState(''), [status,setStatus] = useState('All'), [dark,setDark] = useState(false);
  const visible = rows.filter(r=>(status==='All'||r.status===status)&&`${r.name} ${r.owner}`.toLowerCase().includes(query.toLowerCase().trim()));
  const done = rows.filter(r=>r.status==='Done').length;
  return <div data-theme={dark?'night':'light'} className="min-h-screen bg-base-200 text-base-content"><main className="mx-auto max-w-6xl px-5 py-10">
    <header className="mb-7 flex flex-wrap justify-between gap-4"><div><p className="text-xs uppercase tracking-widest text-primary">Dashboard example · Illustrative data</p><h1 className="mt-2 text-4xl font-semibold">A clear view of the work.</h1><p className="mt-3 text-sm opacity-60">Changes live in this page session and reset when you reload.</p></div><button className="btn btn-outline" onClick={()=>setDark(!dark)}>{dark?'Light theme':'Dark theme'}</button></header>
    <div className="mb-6 grid gap-4 sm:grid-cols-3">{[['Total projects',rows.length],['Completed',done],['Still open',rows.length-done]].map(([label,value])=><div className="stat rounded-xl border border-base-300 bg-base-100" key={label}><div className="stat-title">{label}</div><div className="stat-value text-primary">{value}</div></div>)}</div>
    <section className="card border border-base-300 bg-base-100"><div className="card-body">
      <div className="mb-4 flex flex-wrap items-end gap-4"><div><label htmlFor="search" className="mb-2 block text-sm">Find a project or owner</label><input id="search" className="input input-bordered" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search projects…"/></div><div><label htmlFor="status" className="mb-2 block text-sm">Status</label><select id="status" className="select select-bordered" value={status} onChange={e=>setStatus(e.target.value)}>{['All','Ready','In progress','Done'].map(s=><option key={s}>{s}</option>)}</select></div><button className="btn btn-primary" onClick={()=>downloadJson(visible,'visible-projects.json')}>Export visible rows</button></div>
      <div className="overflow-x-auto"><table className="table"><thead><tr><th>Project</th><th>Owner</th><th>Status</th><th>Action</th></tr></thead><tbody>{visible.map(row=><tr key={row.id}><td className="font-medium">{row.name}</td><td>{row.owner}</td><td><span className={`badge ${row.status==='Done'?'badge-success':'badge-ghost'}`}>{row.status}</span></td><td><button className="btn btn-sm btn-outline" disabled={row.status==='Done'} onClick={()=>setRows(rows.map(r=>r.id===row.id?{...r,status:'Done'}:r))}>Mark done</button></td></tr>)}</tbody></table></div>
      {!visible.length&&<p className="py-8 text-center opacity-60">No projects match these filters.</p>}
      <p className="mt-3 text-xs opacity-50" role="status">Showing {visible.length} of {rows.length} projects</p>
    </div></section>
  </main></div>;
}
createRoot(document.getElementById('root')).render(<App/>);
