# Reusable HTML examples

Use these sources with `../templates/html-page`. Example data is illustrative.
They do not install dependencies, call remote services or require a server.

| Example | Demonstrates |
| --- | --- |
| `chart/` | D3 scales, SVG bars, metric selector, JSON export and themes |
| `network/` | D3 force layout, group/search filters, selection, size slider and graph export |
| `dashboard/` | Summary statistics, searchable/filterable table, state updates and visible-row export |

Start with a new task folder, then replace the starter page with one example:

```bash
cp -R /home/nova/projects/javascript-graphics-template/templates/html-page /absolute/task/page
cp /home/nova/projects/javascript-graphics-template/examples/chart/app.jsx /absolute/task/page/app.jsx
node /absolute/task/page/build.cjs
```

For the network example, also copy `network/extra.css` over the task's `extra.css`.
Open the task's `index.html` directly in a browser. Generated assets stay in the
task folder; the sources in this shared workspace remain reusable.

Adapt the data and labels to the task. Keep graph IDs stable, calculate statistics
from the displayed data and retain clear empty states. Exports are local browser
downloads. Dashboard edits are in-memory and reset on reload.

The earlier network demo was browser-tested in Chrome. These reusable variants
and starter have been built successfully; they have not had a separate browser
interaction run. Their initial task-owned build outputs were under
`/home/nova/a098gws/html-starters/`; that disposable folder has been removed.
Copy and build these maintained sources for new task artifacts.
