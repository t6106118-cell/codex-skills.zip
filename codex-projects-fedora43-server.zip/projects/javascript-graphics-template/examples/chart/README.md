# Chart example

Copy the HTML starter into a task folder, then replace its `app.jsx` with this
file. Run the task copy's `build.cjs`; see `../README.md` for exact commands.

The page uses React and D3 `scaleBand`/`scaleLinear` to draw an SVG bar chart.
The metric selector changes between monthly revenue (thousands of dollars) and
order counts. SVG titles expose bar values on hover. Theme switching and JSON
export demonstrate the shared styling and download helper.

Replace the illustrative `rows` array with task data. Update metric options,
formatting and descriptions together so values and units remain accurate.
