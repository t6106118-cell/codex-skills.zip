import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {scaleBand, scaleLinear, max} from 'd3';
import {downloadJson} from './export.js';

const rows = [
  {month:'Jan', revenue:24, orders:110}, {month:'Feb', revenue:31, orders:145},
  {month:'Mar', revenue:27, orders:130}, {month:'Apr', revenue:42, orders:190},
  {month:'May', revenue:38, orders:172}, {month:'Jun', revenue:52, orders:230},
];
function App() {
  const [metric,setMetric] = useState('revenue');
  const [dark,setDark] = useState(false);
  const x = scaleBand().domain(rows.map(d=>d.month)).range([65,755]).padding(.35);
  const y = scaleLinear().domain([0,max(rows,d=>d[metric])]).nice().range([310,30]);
  const format = value => metric==='revenue' ? `$${value}k` : `${value}`;
  return <div data-theme={dark?'night':'light'} className="min-h-screen bg-base-200 text-base-content"><main className="mx-auto max-w-5xl px-5 py-10">
    <header className="mb-7 flex flex-wrap justify-between gap-4"><div><p className="text-xs uppercase tracking-widest text-primary">Chart example · Illustrative data</p><h1 className="mt-2 text-4xl font-semibold">Six months at a glance.</h1></div><button className="btn btn-outline" onClick={()=>setDark(!dark)}>{dark?'Light theme':'Dark theme'}</button></header>
    <section className="card border border-base-300 bg-base-100"><div className="card-body">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-4"><div><label htmlFor="metric" className="mr-3 text-sm font-semibold">Measure</label><select id="metric" className="select select-bordered" value={metric} onChange={e=>setMetric(e.target.value)}><option value="revenue">Revenue</option><option value="orders">Orders</option></select></div><button className="btn btn-primary" onClick={()=>downloadJson(rows,'monthly-data.json')}>Export data</button></div>
      <svg viewBox="0 0 800 365" className="w-full" role="img" aria-label={`${metric} by month, January to June`}>
        {y.ticks(5).map(t=><g key={t}><line x1="65" x2="755" y1={y(t)} y2={y(t)} stroke="currentColor" opacity=".1"/><text x="55" y={y(t)+4} textAnchor="end" fontSize="12" fill="currentColor">{format(t)}</text></g>)}
        {rows.map(d=><g key={d.month}><rect x={x(d.month)} y={y(d[metric])} width={x.bandwidth()} height={310-y(d[metric])} rx="5" fill="#188b79"><title>{d.month}: {format(d[metric])}</title></rect><text x={x(d.month)+x.bandwidth()/2} y="337" textAnchor="middle" fill="currentColor" fontSize="13">{d.month}</text></g>)}
      </svg>
      <p className="text-sm opacity-60" role="status">{metric==='revenue'?'Revenue shown in thousands of dollars.':'Orders shown as counts.'} Hover over a bar for its value.</p>
    </div></section>
  </main></div>;
}
createRoot(document.getElementById('root')).render(<App/>);
