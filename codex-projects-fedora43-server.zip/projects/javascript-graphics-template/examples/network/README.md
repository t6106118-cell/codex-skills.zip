# Network example

Copy the HTML starter into a task folder. Replace `app.jsx` and `extra.css` with
these files, then run the task's `build.cjs`; see `../README.md` for commands.

Adapted from the browser-tested Fieldnotes demo at
`/home/nova/a098gws/html-demo/`. Uses React and D3 forces to lay out an illustrative
network. Includes search, group filters, node selection, keyboard-operated size
slider, layout regeneration, themes and visible-graph JSON export.

Replace `makeGraph` with task data when needed. Group membership and coordinates
are illustrative; displayed average degree is calculated from visible edges and
nodes. Selected-person degree is explicitly labeled as applying to the full graph.
The reusable variant shares the starter's `downloadJson` helper.
