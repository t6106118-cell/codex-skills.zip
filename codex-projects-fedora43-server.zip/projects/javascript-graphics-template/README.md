# Standalone JavaScript graphics environment

Shared Node/npm dependencies for standalone graphics and image-processing tasks.
Exact direct versions are in `package.json`; `package-lock.json` locks the dependency tree.

## Reusable HTML starter and examples

Start with [templates/html-page](templates/html-page/README.md). Copy it into a
task folder, edit `app.jsx`, then run `node /absolute/task/page/build.cjs`.
The result is a standalone `index.html` with CSS and JavaScript embedded.

See [examples](examples/README.md) for page sources and adaptation notes:

| Example | Features |
| --- | --- |
| [Chart](examples/chart/README.md) | SVG bars, D3 scales, metric selection and export |
| [Network](examples/network/README.md) | Force layout, filters, selection and graph export |
| [Dashboard](examples/dashboard/README.md) | Summary cards, filtered table and editable state |

Templates and examples are maintained reusable sources. Keep task-specific data,
copied page sources and all generated outputs in the task workspace. No extra
packages or per-task installation are needed to use these examples here.

## Shared Node runtime

Run a task-owned CommonJS script from any directory:

```bash
NODE_PATH=/home/nova/projects/javascript-graphics-template/node_modules \
  node /absolute/task/script.cjs
```

Use `require('react')`, `require('react-dom/server')`, `require('react-icons/fa')`,
or `require('sharp')` as needed. Node does not execute JSX directly; use the
installed esbuild for JSX/TSX and TypeScript transformation and browser bundles.
Native ESM imports do not use `NODE_PATH`; use a task's own package environment
or bundle the source with esbuild using the shared dependency path.

Keep task scripts, inputs, and outputs at explicit task paths outside this folder.
Application dependencies belong in the application's own package environment.
To restore this shared environment when necessary, run
`npm ci --prefix /home/nova/projects/javascript-graphics-template`.

## Charts, motion and SVG export

| Job | Installed libraries |
| --- | --- |
| Hand-authored SVG charts and animated axes | `d3` and `react` in the [HTML starter](templates/html-page/README.md) |
| Standard charts as SVG from Node | `echarts` with its SVG renderer and `ssr: true` |
| Statistical charts as SVG | `@observablehq/plot`. Pass a `jsdom` document when exporting from Node. |
| Staggers, SVG path motion and seekable timelines | `animejs` and `gsap` |
| React and DOM transitions | `motion`, including `motion/react` |
| 3D in the browser | `three` |
| SVG size reduction | `svgo`. Preserve the `viewBox`, accessibility metadata and IDs used by scripts. |

For an animated chart, derive bars, ticks, annotations, and value labels from
the same data and scale at each frame. Apply a unit conversion to both the
values and the axis domain so a change of units preserves the bar heights.
Keep editable labels as text. Use inline SVG in HTML for JavaScript timelines
and interaction. [D3 linear scales](https://d3js.org/d3-scale/linear) ·
[SVG processing modes](https://www.w3.org/TR/SVG/latest/conform.html)

Use the [animation rendering environment](../animation-rendering/README.md)
for deterministic video export and 3D or math renders.

## Network graphs

Graphology (`graphology`) and Sigma.js (`sigma`) are installed directly from npm,
independently of Gephi Lite. Their exact versions are recorded in `package.json`.

Use `require('graphology')` in task-owned CommonJS scripts to construct graphs,
edit attributes and serialize graph data with `graph.export()`. Graphology's
layout, metrics and community algorithms are separate standard-library packages.
The following companion packages are installed here:

| Package | Capability |
| --- | --- |
| `graphology-layout-forceatlas2` | ForceAtlas2 node positions |
| `graphology-communities-louvain` | Community detection |
| `graphology-metrics` | Graph metrics |
| `graphology-gexf` | GEXF parsing and writing |
| `graphology-graphml` | GraphML parsing (see package API for supported operations) |

D3 (`d3`) is also installed for custom charts, hierarchies, maps and force
simulations. Its package uses ES modules: native ESM imports do not resolve
through `NODE_PATH`; use a task-local package environment for browser builds
or ESM entrypoints.

Sigma.js renders interactive graphs with WebGL in a browser. Use it in generated
HTML/JavaScript with Graphology data, via a browser bundle or a task-local browser
build. It is not a terminal PNG renderer; a Node-only script cannot instantiate
the browser renderer without a browser environment. No Gephi Lite checkout or
API account is required. Consult documentation matching the installed Sigma
major version before writing renderer code.

## HTML pages and browser bundles

The shared environment includes esbuild, Tailwind CSS, `@tailwindcss/cli` and
daisyUI. Exact versions are pinned in `package.json` and `package-lock.json`.

- esbuild transforms JSX/TSX/TypeScript and bundles browser JavaScript. It does
  not perform TypeScript type checking. From a task-owned CommonJS build script,
  load `require('esbuild')` using the `NODE_PATH` invocation above; set esbuild's
  `nodePaths` to this environment's `node_modules` to resolve shared dependencies.
- Tailwind provides styling utilities; daisyUI adds styled components and themes.
  Both are compiled into CSS for generated pages.

Invoke the installed CSS CLI with explicit task paths:

```bash
/home/nova/projects/javascript-graphics-template/node_modules/.bin/tailwindcss \
  -i /absolute/task/input.css -o /absolute/task/style.css --minify
```

When the input CSS is outside this environment, resolve its Tailwind imports
and daisyUI plugin against the shared `node_modules` using absolute paths.
Explicitly point Tailwind's source scanning at the task's HTML/JSX files rather
than the shared environment. The build script can inline generated CSS and
JavaScript into HTML when a single-file artifact is required.

Keep all page sources, build scripts and outputs in the task workspace. Vite
remains a per-application dependency when a web application is actually created.

The esbuild and `@parcel/watcher` install hooks were approved through npm's
`approve-scripts` command, then rebuilt successfully. No extra smoke tests or
browser checks were run during installation.

The maintained [HTML starter](templates/html-page/README.md) and
[network example](examples/network/README.md) contain the reusable build path.
Their CSS uses absolute imports of `tailwindcss/index.css`, `daisyui/index.js`
and `daisyui/theme/index.js`, plus a task-local `@source` to bound scanning.
Their build script uses esbuild `nodePaths` for shared packages.

An earlier disposable network demo was built and browser-tested on 2026-11-10,
including filters, theme, selection, graph sizing, JSON download and 390px
layout overflow. That task folder (`/home/nova/a098gws/html-demo`) has since been
removed. The maintained starter and examples built successfully on that date;
the browser results apply to the earlier demo.
