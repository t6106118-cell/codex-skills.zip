# Working instructions
Read CURRENT_STATE.md before substantive work in this shared environment.
Keep npm dependencies and lockfile here; keep task-owned scripts, data and generated outputs in each task's workspace. See README.md for runtime usage.
For standalone HTML pages, read templates/html-page/README.md and copy that starter into the task workspace. Read examples/README.md for chart, network and dashboard sources. Shared templates and examples are reusable sources; build generated HTML in task-owned copies.
