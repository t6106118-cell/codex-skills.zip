// Browser helper: serialize data, download it locally, then release the Blob URL.
export function downloadJson(data, filename = 'data.json') {
  const json = JSON.stringify(data, null, 2);
  if (json === undefined) throw new TypeError('Cannot export an undefined JSON value');
  const url = URL.createObjectURL(new Blob([json], {type: 'application/json'}));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
