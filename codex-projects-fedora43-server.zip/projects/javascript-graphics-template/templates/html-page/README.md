# Standalone HTML starter

Copy this directory into a new task-owned folder. It uses the shared environment's
pinned packages without installing another node_modules directory.

```bash
cp -R /home/nova/projects/javascript-graphics-template/templates/html-page /absolute/task/page
node /absolute/task/page/build.cjs
```

Open `/absolute/task/page/index.html` in a browser. CSS and browser JavaScript are
embedded in that one file; no CDN or server is needed. Fonts use system fallbacks.

| File | Purpose |
| --- | --- |
| `app.jsx` | React page content, data and interactions |
| `input.css` | Tailwind imports, daisyUI theme and explicit source scanning |
| `extra.css` | Task-specific CSS |
| `export.js` | Browser JSON-download helper |
| `build.cjs` | Tailwind compilation, esbuild bundling and HTML generation |

Edit the `title` constant in `build.cjs` for the browser-tab title. Edit the
page's heading and content in `app.jsx`. Import `downloadJson` from `./export.js`
for JSON downloads. It reports serialization errors rather than discarding data.

Add explicit `@source` paths to `input.css` if you split components into other
files. Use complete Tailwind class names so the scanner can discover them.
The build script resolves shared dependencies with esbuild `nodePaths` and a
Node `createRequire`; the command needs no NODE_PATH environment variable.
JSX is transformed by esbuild; it does not type-check TypeScript.

Build in the task copy. The script rejects builds inside the shared workspace
so generated HTML/CSS stay with the task. Input files and shared dependency paths
are local workstation paths; the generated HTML does not depend on those paths.
Moving this environment requires updating the shared paths in build.cjs/input.css.

For a chart, network explorer or dashboard, follow the examples index at
`/home/nova/projects/javascript-graphics-template/examples/README.md`. Examples supply page sources and optional extra CSS;
they reuse this starter's build and export helper.
