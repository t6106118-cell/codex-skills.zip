const fs = require('node:fs');
const path = require('node:path');
const {createRequire} = require('node:module');
const {execFileSync} = require('node:child_process');

const shared = '/home/nova/projects/javascript-graphics-template';
const modules = path.join(shared, 'node_modules');
const root = fs.realpathSync(__dirname);
if (root === shared || root.startsWith(shared + path.sep)) {
  throw new Error('Copy this starter into a task folder before building. Generated files belong with the task.');
}
const esbuild = createRequire(path.join(shared, 'package.json'))('esbuild');
const title = 'Interactive page'; // Set the browser-tab title for this task.
execFileSync(path.join(modules, '.bin/tailwindcss'), [
  '-i', path.join(root, 'input.css'), '-o', path.join(root, 'style.css'), '--minify',
], {cwd: root, stdio: 'inherit'});
const result = esbuild.buildSync({
  entryPoints: [path.join(root, 'app.jsx')],
  bundle: true, write: false, format: 'iife', platform: 'browser',
  jsx: 'automatic', minify: true, nodePaths: [modules],
  define: {'process.env.NODE_ENV': '"production"'},
});
const escapeHtml = text => text.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const css = fs.readFileSync(path.join(root, 'style.css'), 'utf8').replace(/<\/style/gi, '<\\/style');
const js = result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const html = `<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(title)}</title><style>${css}</style></head>
<body><div id="root"></div><script>${js}</script></body></html>`;
const output = path.join(root, 'index.html');
fs.writeFileSync(output, html);
console.log(`Built ${output} (${Buffer.byteLength(html)} bytes; JavaScript and CSS embedded)`);
