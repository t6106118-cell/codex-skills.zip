import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {downloadJson} from './export.js';

function App() {
  const [dark, setDark] = useState(false);
  const [message, setMessage] = useState('Ready to make something useful.');
  return <div data-theme={dark ? 'night' : 'light'} className="min-h-screen bg-base-200 text-base-content">
    <main className="mx-auto max-w-5xl px-5 py-10 md:px-10">
      <header className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div><p className="mb-2 text-xs font-semibold uppercase tracking-widest text-primary">Standalone HTML starter</p><h1 className="text-4xl font-semibold">Your next useful page.</h1><p className="mt-3 opacity-60">Replace this content with your task's data and interactions.</p></div>
        <button className="btn btn-outline" onClick={() => setDark(!dark)}>{dark ? 'Light theme' : 'Dark theme'}</button>
      </header>
      <section className="card border border-base-300 bg-base-100">
        <div className="card-body gap-5"><h2 className="card-title">A working starting point</h2><p role="status">{message}</p>
          <div className="card-actions"><button className="btn btn-primary" onClick={() => setMessage('The React interaction is working.')}>Try interaction</button><button className="btn btn-outline" onClick={() => downloadJson({message}, 'starter-data.json')}>Export JSON</button></div>
        </div>
      </section>
    </main>
  </div>;
}
createRoot(document.getElementById('root')).render(<App/>);
