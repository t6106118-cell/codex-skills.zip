# Web retrieval environment

Read CURRENT_STATE.md before substantive work in this environment.
Use README.md for package roles and invocation examples.

Keep dependencies in this uv-managed project. Task-specific scripts, spiders,
downloaded files and generated data belong in each task's workspace.
Use installed Google Chrome for Playwright-backed crawling. Preserve existing
browser sessions, proxy settings and credentials; configure task-specific
network behavior when needed by the actual retrieval operation.
