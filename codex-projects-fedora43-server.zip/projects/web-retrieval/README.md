# Internet search and retrieval environment

Reusable uv-managed dependencies for task-owned network scripts and crawlers.
System Python 3.14.10 created this environment. The manifest and uv.lock own
the dependency selection; system Python and the analysis environment were not
modified. Keep downloaded files, scripts, spiders and outputs in task folders.

## Installed capabilities

Installed successfully on 2026-11-11:

| Package | Version | Use |
| --- | --- | --- |
| DDGS | 9.16.1 | Programmable web search |
| HTTPX | 0.28.1 with HTTP/2 extra | HTTP APIs, asynchronous requests and downloads |
| BeautifulSoup | 4.15.0 | HTML parsing and CSS selection |
| lxml | 6.1.3 | HTML/XML parsing, XPath and table extraction |
| Trafilatura | 2.3.1 | Main text, metadata, sitemap/feed discovery and extraction |
| feedparser | 6.0.14 | RSS and Atom feed parsing |
| Scrapy | 2.20.0 | Crawling, scheduling and structured data export |
| scrapy-playwright | 0.0.48 | JavaScript rendering for selected Scrapy requests |
| Playwright | 1.65.0 | Browser automation dependency, using installed Chrome |
| huggingface_hub | 2.4.0 | Hub file/dataset downloads and the hf CLI |

The workstation also has Fedora rclone 1.75.2-2.fc44 for remote file transfers.
Existing curl, Wget2, aria2c, yt-dlp, Surf and the fetch-url-markdown skill remain
available. Built-in web search and connected research tools supply cited
research; these packages add programmable local retrieval workflows.

## Run task scripts and commands

```bash
uv run --project /home/nova/projects/web-retrieval python /absolute/task/script.py
uv run --project /home/nova/projects/web-retrieval scrapy runspider /absolute/task/spider.py -O /absolute/task/items.jsonl
uv run --project /home/nova/projects/web-retrieval trafilatura -u 'https://example.com/article'
```

Replace example URLs and task paths with the requested sources and outputs.
Trafilatura writes main text to stdout in this example. Scrapy's `-O` replaces
the named output; use it for the intended task artifact.

For scripted search, the documented DDGS API is:

```python
from ddgs import DDGS

results = DDGS().text("research topic", max_results=5)
```

Search results identify candidate sources; retrieve the original pages for
the requested data and citations. Search-engine availability is established by
the actual search operation, not by this installation result.

## JavaScript pages with system Chrome

scrapy_settings.py activates the Playwright download handlers and selects the
installed Chrome channel in headless mode. Use it for a task-owned spider:

```bash
PYTHONPATH=/home/nova/projects/web-retrieval${PYTHONPATH:+:$PYTHONPATH} \
SCRAPY_SETTINGS_MODULE=scrapy_settings \
uv run --project /home/nova/projects/web-retrieval scrapy runspider /absolute/task/spider.py -O /absolute/task/items.jsonl
```

Set `meta={"playwright": True}` on the spider's requests that need browser
rendering. Other requests use the regular Scrapy handler. This launches a
separate browser context; it does not attach to the active Surf/Chrome session.
No additional browser download or existing profile change was performed.

HTTPX uses proxy environment variables by default. Browser proxy settings are
separate: when needed, supply a task-specific Playwright `proxy` launch option
alongside the Chrome channel. Existing Xray, GNOME and shell proxy settings
were not changed by setup.

## Public datasets and remote files

For one requested dataset file, replace REPO_ID and FILE with its identifiers:

```bash
uv run --project /home/nova/projects/web-retrieval hf download REPO_ID FILE --repo-type dataset --local-dir /absolute/task/data
```

The hf CLI supports revision selection and local download metadata. Access
to private or gated repositories depends on that source's credentials.
For a configured storage remote, use `rclone copy remote:path /absolute/task/data`.
Installation did not add accounts, cloud remotes or credentials, or download
example datasets.

## Restore and maintain

Restore dependencies only when necessary with
`uv sync --project /home/nova/projects/web-retrieval --locked`.
Use `uv add --project /home/nova/projects/web-retrieval PACKAGE` for dependency
changes. Manage rclone with Fedora DNF. Keep task data outside this environment.
No post-install browser, search, import or download smoke tests were run.

## Source documentation

- [DDGS](https://github.com/deedy5/ddgs)
- [HTTPX proxy environment](https://www.python-httpx.org/environment_variables/)
- [Trafilatura](https://trafilatura.readthedocs.io/en/stable/)
- [Scrapy installation](https://docs.scrapy.org/en/latest/intro/install.html)
- [scrapy-playwright setup](https://scrapy-playwright.readthedocs.io/en/latest/setup.html)
- [Playwright browser channels](https://playwright.dev/python/docs/browsers)
- [Hugging Face CLI](https://huggingface.co/docs/huggingface_hub/en/guides/cli)
- [rclone](https://rclone.org/docs/)
