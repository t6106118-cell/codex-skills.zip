# Analysis environment

Read CURRENT_STATE.md before substantive work. Use project-local uv dependencies and keep task files outside this shared environment.
