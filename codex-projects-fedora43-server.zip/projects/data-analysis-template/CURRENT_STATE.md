# Current state

Source files supplied for the Fedora 43 server setup. See the top-level SETUP.md in the transfer archive.

Restore the locked uv analysis environment.
