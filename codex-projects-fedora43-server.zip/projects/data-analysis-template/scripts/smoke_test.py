"""Exercise the approved Phase 5 analysis capabilities without persistent output."""

from __future__ import annotations

import io
import json
import tempfile
from pathlib import Path

import ipykernel
import jupyterlab
import matplotlib
import numpy as np
import openpyxl
import pandas as pd
import scipy
from scipy import stats

matplotlib.use("Agg")
from matplotlib import pyplot as plt  # noqa: E402


def main() -> None:
    # Numerical and statistical work.
    values = np.array([1.0, 2.0, 3.0, 4.0])
    assert np.isclose(values.mean(), 2.5)
    result = stats.describe(values)
    assert result.nobs == 4

    # Pandas/OpenPyXL Excel round trip, including Persian and mixed text.
    frame = pd.DataFrame(
        {
            "label": ["فارسی", "English", "مقدار / value"],
            "amount": [1.25, 2.5, 3.75],
        }
    )
    with tempfile.TemporaryDirectory(prefix="phase5-analysis-") as temp_dir:
        workbook_path = Path(temp_dir) / "roundtrip.xlsx"
        frame.to_excel(workbook_path, index=False, engine="openpyxl")
        loaded = pd.read_excel(workbook_path, engine="openpyxl")
        pd.testing.assert_frame_equal(loaded, frame)

    # Headless chart rendering suitable for scripts and notebooks.
    figure, axes = plt.subplots()
    axes.plot(values, values**2)
    png = io.BytesIO()
    figure.savefig(png, format="png")
    plt.close(figure)
    assert png.getvalue().startswith(b"\x89PNG\r\n\x1a\n")

    versions = {
        "ipykernel": ipykernel.__version__,
        "jupyterlab": jupyterlab.__version__,
        "matplotlib": matplotlib.__version__,
        "numpy": np.__version__,
        "openpyxl": openpyxl.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
    }
    print(json.dumps({"status": "PASS", "versions": versions}, sort_keys=True))


if __name__ == "__main__":
    main()
