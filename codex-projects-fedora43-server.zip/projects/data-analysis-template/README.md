# Data analysis template

This is a reusable, project-local Fedora 44 workspace for notebooks, scientific
Python, plotting, and Excel data exchange. `uv` owns both the lockfile and the
`.venv`; nothing is installed into the system Python or the Python user site.

## Start working

From this directory:

```bash
uv sync --locked --no-python-downloads
uv run jupyter lab
```

Open `notebooks/quickstart.ipynb` in JupyterLab. In VS Code, open this folder and
select `.venv/bin/python` as the interpreter. A global Jupyter kernelspec is not
needed: both JupyterLab and VS Code can use the environment directly.

Run the non-interactive capability check with:

```bash
uv run python scripts/smoke_test.py
```

## Network graphs

NetworkX and Plotly are installed in this environment. Use NetworkX for graph
analysis, community detection and layouts, including `nx.forceatlas2_layout`.
Use Matplotlib for static PNG/SVG/PDF figures or Plotly for interactive HTML
with zoom and hover. Basic Plotly network figures do not include node dragging
or live layout controls.

Run task-owned scripts from any working directory with:

```bash
uv run --project /home/nova/projects/data-analysis-template python /absolute/task/script.py
```

Keep scripts, inputs and generated graphs in the task workspace. For a standalone
HTML file that works offline, use `fig.write_html(path, include_plotlyjs=True)`.
No API account, additional plugin or browser automation is needed to generate it.

## Additional analysis and export libraries

- Kaleido enables Plotly `fig.write_image(path)` for PNG, SVG, PDF and other
  supported static formats. Kaleido uses a compatible Chrome/Chromium runtime;
  use the installed browser rather than downloading another copy by default.
- SymPy provides symbolic algebra, equation solving, differentiation and integration.
- scikit-learn provides preprocessing, clustering, dimensionality reduction and
  predictive models; import it as `sklearn`.

These packages are installed in this environment; exact resolved versions are
recorded in `uv.lock`. Package installation succeeded on 2026-11-10; no additional
runtime or browser checks were performed for these additions.

## Dependency policy

The direct dependencies in `pyproject.toml` are the approved core, including
NetworkX, Plotly, Kaleido, SymPy, scikit-learn, DuckDB, Polars, PyArrow,
fastexcel, XlsxWriter and GeoPandas for analysis, data exchange and visualization.
Keep additional project-specific packages in the project that actually needs
them. Database drivers, SQLAlchemy and extra visualization libraries remain
task-specific choices. Use `uv add` for
intentional dependency changes; it updates the manifest and lockfile together.
Include both files in an authorized repository commit when applicable.

For a new analysis project, copy the small source files (`pyproject.toml`,
`uv.lock`, `.gitignore`, and the useful examples), but do not copy `.venv`.
Run `uv sync --locked --no-python-downloads` in the new location to recreate it.

## Local SQL and columnar data processing

Installed with `uv add` on 2026-11-11:

| Package | Version | Use |
| --- | --- | --- |
| DuckDB | 2.0.0 | Embedded SQL queries over CSV, JSON and Parquet files |
| Polars | 2.1.0 | Dataframe transformations and lazy CSV/Parquet scanning |

Use `import duckdb` and `import polars as pl` from task-owned Python scripts,
using the `uv run --project ...` invocation above. DuckDB runs inside Python;
no database server or separate DuckDB CLI was installed. Polars uses its
matching `polars-runtime-32` 2.1.0 package. The core installation was followed
by the Arrow and Excel dependencies below. Cloud and GPU extras were not added.

References: [DuckDB Python API](https://duckdb.org/docs/2.0/clients/python/overview.html),
[Polars installation](https://docs.pola.rs/user-guide/installation/),
[lazy CSV scanning](https://docs.pola.rs/api/python/stable/reference/api/polars.scan_csv.html).
Installation completed successfully; no additional runtime tests or performance
benchmarks were run.

## Arrow, Excel and vector geospatial data

Installed with `uv add` on 2026-11-11:

| Package | Version | Use |
| --- | --- | --- |
| PyArrow | 26.0.1 | Arrow interchange and pandas Parquet reading/writing |
| fastexcel | 0.21.0 | Excel reading through Polars' calamine engine |
| XlsxWriter | 3.3.1 | Excel workbook export, including Polars' writer |
| GeoPandas | 1.2.0 | Vector geospatial dataframes and map plotting |
| Shapely | 2.2.0 | Geometry operations; GeoPandas dependency |
| PyProj | 3.8.0 | Coordinate systems and transformations; GeoPandas dependency |
| PyOgrio | 0.13.0 | Vector file I/O; GeoPandas dependency |

Use the same task-owned scripts and `uv run --project ...` invocation above.
Import names include `pyarrow`, `fastexcel`, `xlsxwriter` and `geopandas`.
GeoPandas reads and writes formats such as GeoJSON, GeoPackage and Shapefile;
the existing Matplotlib installation supplies static plotting. These packages
add vector geospatial processing; raster and interactive web-map packages were
not selected.

References: [Arrow Python documentation](https://arrow.apache.org/docs/python/index.html),
[Polars Excel documentation](https://docs.pola.rs/user-guide/io/excel/),
[GeoPandas ecosystem and dependencies](https://github.com/geopandas/geopandas/blob/ead9a4fe380b3e5cb189fca03328af4e1db5fa33/doc/source/community/ecosystem.md).
uv installed all seven packages successfully and updated the manifest and
lockfile. No additional import, file-conversion, plotting or performance tests
were run.

