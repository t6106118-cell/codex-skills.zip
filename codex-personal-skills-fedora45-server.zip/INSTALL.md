# Install the personal Codex skills on Fedora 45

This archive contains 42 personal skills in `skills/`. Each folder includes
its `SKILL.md` and supporting resources, including any source and lockfiles.

1. Extract the archive to a temporary directory on the server.
2. Install the contents of `skills/` into `$CODEX_HOME/skills`. When
   `CODEX_HOME` is unset, use `~/.codex/skills`. Preserve existing unrelated
   skills and reconcile local customizations in any matching skill folders.
3. Use each skill's `RUNTIME.md` or linked setup instructions to install the
   external tools you need. Resolve source-workstation paths such as
   `/home/nova` against the server's actual account and installed paths.
4. Start or reopen Codex CLI after installation so it can discover the skills.

The bundle omits the source workstation's `.system` folder, installed Python
and npm environments, and generated Python caches. Recreate needed dependencies
from the included lockfiles. Browser sessions, account credentials, plugins,
MCP configuration, and external executables are managed by the server separately.
