# AnyDoc runtime

The installed CLI is `~/.local/bin/anydoc`. It resolves to the custom
`@firecrawl/anydoc@0.2.4-e7178e099b6b` package in
`~/.local/opt/fedora45-tools/anydoc`. The package includes the Linux x64 GNU
native addon and uses Node.js 20 or later.

## Restore the installed package

The install root contains `package.json`, `package-lock.json`, and the archive
`firecrawl-anydoc-0.2.4-e7178e099b6b.tgz`. The lockfile references the archive by
relative path and supplies its integrity digest. Restore from that root with:

```bash
npm ci --prefix "$HOME/.local/opt/fedora45-tools/anydoc" --omit=dev --omit=optional
```

The public command links to
`~/.local/opt/fedora45-tools/anydoc/node_modules/.bin/anydoc`.

## Rebuild from source

The maintained sources and locks are in `/home/nova/a1/sources`. AnyDoc is
pinned to `e7178e099b6bf9171e2c52b832cbdb4134b69112` and uses the sibling PDF
Inspector checkout at `bcf387d1f4ab91d702f417fd9600694da0c166c3`. Its local
Cargo path dependency, npm package version, native addon and `LOCAL_SOURCE.json`
are part of the custom package build.

Run `npm ci` and `npm run build` in `firecrawl--anydoc/node`, then package it
with `npm pack`. Keep the native addon and `LOCAL_SOURCE.json` in the archive.
Install the archive into the managed root using npm so the local dependency
and its integrity are recorded in the lockfile.

Conversion defaults to local processing. An explicitly requested Firecrawl
hosted workflow can select `--parse-mode auto|fast|ocr`. For scanned PDFs use
the local OCR route in the PDF Inspector skill when it meets the task.
