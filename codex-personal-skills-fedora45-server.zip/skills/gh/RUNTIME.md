# GitHub CLI runtime provisioning

On this Fedora workstation, use `/usr/bin/gh` from DNF. The installed version
was 2.97.0 when this guide was refreshed. The skill examples come from GitHub
CLI v2.103.3. Check local help when a version-specific option is needed.

On a fresh Fedora machine, install `gh` through DNF. If a required feature
needs a newer release, use [GitHub's RPM repository instructions](https://github.com/cli/cli/blob/trunk/docs/install_linux.md#rpm).
For DNF5, those instructions use the following commands.

```bash
sudo dnf install dnf5-plugins
sudo dnf config-manager addrepo --from-repofile=https://cli.github.com/packages/rpm/gh-cli.repo
sudo dnf install gh
```

Keep package-signature verification enabled. When an authenticated GitHub
operation requires sign-in, use `gh auth login`.
