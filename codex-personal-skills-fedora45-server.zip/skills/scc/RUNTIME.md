# scc runtime

`~/.local/bin/scc` links to the official `v4.1.0` executable at
`~/.local/opt/fedora45-tools/scc/v4.1.0/bin/scc`. The release asset and SHA-256
are recorded in the [workstation manifest](/home/nova/a1/release-tools-installed.json).

## Restore scc

```bash
(
  set -eu
  scc_root="$HOME/.local/opt/fedora45-tools/scc/v4.1.0"
  scc_dir=$(mktemp -d)
  trap 'rm -rf -- "$scc_dir"' EXIT
  cd "$scc_dir"
  curl --fail --location --output scc.tar.gz \
    https://github.com/boyter/scc/releases/download/v4.1.0/scc_Linux_x86_64.tar.gz
  printf '%s  %s\n' c7328436d3027f4357d3d7853f7dc3ac2bbcb4ca08f1adad91a27c593884079b scc.tar.gz | sha256sum --check
  tar -xzf scc.tar.gz scc
  install -Dm0755 scc "$scc_root/bin/scc"
)
```

The public symlink points to `bin/scc` inside that managed root. For an upgrade,
use the official asset matching the host architecture, compare the publisher's
digest, update the command link and remove the retired installation root.

Use the CLI for ordinary work. `scc --mcp` starts an optional stdio server.
Register it only when a task needs that transport.
