# Surf runtime

This workstation uses the user-local `surf-cli@2.26.0` installation. The `surf`
command resolves to `~/.local/lib/node_modules/surf-cli/native/cli.cjs`. The
unpacked Surf extension is `~/.local/lib/node_modules/surf-cli/dist` with ID
`oaclimdkkglbnpekeignmjenkodkaaka`.

## Restore or update Surf

```bash
npm install --global --prefix "$HOME/.local" surf-cli@2.26.0
node "$HOME/.local/lib/node_modules/surf-cli/scripts/install-native-host.cjs" --refresh
```

Run both as the normal user. The native-host refresh maintains per-user browser
registration and the wrapper in `~/.local/share/surf-cli`. Check each browser's
registered host only when diagnosing a connection failure. BrowserOS Neo has
its own registration under `~/.config/browser-claw/NativeMessagingHosts`.

## BrowserOS on this workstation

The `browseros-neo` launcher requests the Surf extension and HTTP proxy
`127.0.0.1:10810`. It leaves Chrome DevTools Protocol port selection to BrowserOS,
whose saved port is `9111`. Native BrowserOS MCP is `127.0.0.1:9010/mcp`.
BrowserOS is started manually alongside Codex. If a task needs it and it is
closed, ask the user to open it.

Use `surf doctor` to diagnose a missing socket or version mismatch. Let Surf's
native host create its socket. See [the command reference](references/command-reference.md)
for CLI syntax and the [workstation guide](/home/nova/a1/FEDORA45_WORKSTATION.md)
for current browser integration paths.
