# PDF Inspector runtime

`pdf2md` and `detect-pdf` resolve through `~/.local/bin` to
`~/.local/opt/fedora45-tools/pdf-inspector/bin`. `dump_ops` lives in the same
managed directory. The build uses PDF Inspector 1.25.2 at commit
`bcf387d1f4ab91d702f417fd9600694da0c166c3`, which includes the font subset and
spacing fixes used by the AnyDoc build.

## Restore the native commands

The source and selected Cargo lockfile are in
`/home/nova/a1/sources/firecrawl--pdf-inspector`. Use Fedora's Rust toolchain
and the existing lockfile:

```bash
cargo install --path /home/nova/a1/sources/firecrawl--pdf-inspector \
  --locked --root "$HOME/.local/opt/fedora45-tools/pdf-inspector" \
  --no-default-features --bins
```

The public symlinks target `bin/pdf2md` and `bin/detect-pdf` in that root.
For a same-version rebuild, use Cargo's `--force` only when intentionally
replacing the installed binaries.

This build handles native extraction and classification. It excludes the
optional Firecrawl OCR components. Use OCRmyPDF and the installed English or
Persian Tesseract language pack for scanned pages. The CLI's `--help` prints
usage to stderr and returns 1. See [SKILL.md](SKILL.md) for its file contract.
