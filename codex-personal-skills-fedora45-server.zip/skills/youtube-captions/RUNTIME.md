# YouTube download runtimes

| Tool | Workstation installation | Role |
| --- | --- | --- |
| `yt-dlp` | Official Linux standalone binary `2026.10.26` in `~/.local/bin` | Resolves caption and media formats |
| `deno` | Official npm `deno@2.9.6` in `~/.local/lib/node_modules/deno` | YouTube JavaScript challenges |
| `ffmpeg`, `ffprobe` | RPM Fusion FFmpeg 9.0.2 | Caption conversion and media processing |

## Restore or update

The standalone `yt-dlp` uses its own Python runtime. Update with `yt-dlp --update`.
For a fresh installation, use the [official Linux executable](https://github.com/yt-dlp/yt-dlp/releases/download/2026.10.26/yt-dlp_linux).
The recorded SHA-256 for this asset is
`767ba9dce7052aa196f8b12652f433d76de128ba168966fa84b6394d5e6c6795`.
Compare the release digest before installing it at `~/.local/bin/yt-dlp`.
Restore Deno with `npm install --global --prefix "$HOME/.local" deno@2.9.6`.
Use the existing RPM Fusion package source for FFmpeg.

## JavaScript solver configuration

`~/.config/yt-dlp/config` contains `--remote-components ejs:npm`. This allows
yt-dlp to retrieve external solver components from `yt-dlp-ejs` when needed.
Deno is enabled by default when the executable is on PATH. Run `yt-dlp` with
its normal configuration. For a solver error, inspect the runtime and the
reported extraction error with `yt-dlp --verbose --list-subs --no-playlist URL`.

For caption downloads, follow [SKILL.md](SKILL.md), including `--skip-download`.
The media workflow is documented in the [media download skill](../youtube-media-download/SKILL.md).
