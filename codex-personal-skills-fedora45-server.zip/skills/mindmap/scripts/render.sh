#!/usr/bin/env bash
# render.sh — render a Markmap .md to standalone interactive HTML.
# Usage: render.sh <md-path> [html-path]
# Exit codes: 0 ok | 1 usage | 2 md not found | 3 Markmap missing | 4 render failed
set -euo pipefail

md="${1:-}"
if [ -z "$md" ]; then
  echo "usage: render.sh <md-path> [html-path]" >&2
  exit 1
fi

if [ ! -f "$md" ]; then
  echo "error: markmap file not found: $md" >&2
  exit 2
fi

html="${2:-}"
if [ -z "$html" ]; then
  # swap trailing .md for .html (handles foo.mindmap.md -> foo.mindmap.html)
  html="${md%.md}.html"
fi

if [ "$md" -ef "$html" ]; then
  echo "error: refusing to overwrite the source Markdown: $md" >&2
  exit 4
fi

if ! command -v markmap >/dev/null 2>&1; then
  echo "error: Markmap CLI not found. Install @markmap/cli as described in RUNTIME.md." >&2
  exit 3
fi

# Keep stdout limited to the output path for callers.
if ! markmap --no-open -o "$html" -- "$md" >&2; then
  echo "error: Markmap could not render: $md" >&2
  exit 4
fi

printf '%s\n' "$html"
