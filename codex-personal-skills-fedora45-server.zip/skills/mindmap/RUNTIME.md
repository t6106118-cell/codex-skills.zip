# Markmap HTML runtime

The workstation uses `markmap` from `@markmap/cli@1.1.1`, with Node.js 22 or
later. Restore the CLI in the user-local prefix with:

```bash
npm install --global --prefix "$HOME/.local" @markmap/cli@1.1.1
```

Render one Markdown file with [the skill helper](scripts/render.sh):

```bash
bash "${CODEX_HOME:-$HOME/.codex}/skills/mindmap/scripts/render.sh" input.md output.html
```

The helper runs `markmap --no-open` and prints the output path. Markmap 1 embeds
its runtime assets in exported HTML. Local images can be embedded and external
links or remote images still require network access. Ordinary Markdown needs no
CLI. Use `colorDepth` and `wrapWidth` for the current frontmatter options.
See the [Markmap migration guide](https://markmap.js.org/docs/migration) when
working with files written for the 0.18 renderer.
