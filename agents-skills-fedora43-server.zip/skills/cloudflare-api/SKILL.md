---
name: cloudflare-api
description: Operate Cloudflare account resources through the connected Cloudflare plugin or configured Cloudflare Code Mode MCP, including DNS, Workers, R2, D1 and API discovery. Use for Cloudflare account API tasks or questions about these integrations; use kitesurf for remote browser interaction.
---

# Cloudflare Code Mode on this workstation

The connected Cloudflare plugin has the app-specific **Allow all actions**
setting, as requested by the user. On 2026-11-18 it successfully listed an
account and created and deleted a temporary empty Workers KV namespace. That
confirms account-list access and Workers KV writes through the plugin.

Codex MCP server `cloudflare-api` is configured at
`https://mcp.cloudflare.com/mcp` in `/home/nova/.codex/config.toml`.
Its OAuth login completed on 2026-11-11 with the user's explicit full-scope
choice, including the separate Account API Tokens Write permission. Preserve
that authorization; do not impose read-only scope or request routine permission
again. Authorization does not require making unrelated resource changes.
The user has a zero-budget requirement: do not enable billing or paid plans.

This server operates Cloudflare account APIs. It is separate from the
`kitesurf` remote browser MCP and its Browser Run-only API token. A local browser
login, this OAuth grant and the KiteSurf token are different credentials.

## Use the live tools

Use the connected Cloudflare plugin when its tools are available. Use the
configured `cloudflare-api` registration in sessions that expose that toolset.
Read the live schemas. Default Code Mode provides:

| Tool | Purpose |
| --- | --- |
| `docs` | Search Cloudflare developer documentation |
| `search` | Execute JavaScript against `spec.paths` to discover API operations |
| `execute` | Execute JavaScript calling `cloudflare.request()` |
| `whoami` | Identify the connected user/account when the task needs that information |

Search for the relevant endpoint and its schema, then execute the requested API
operation. Resolve account/zone identifiers from task context or relevant API
results. Filter results inside the code before returning them to the model.
Do not run unrelated availability/identity probes before an already known operation.

Keep default Code Mode; `?codemode=false` exposes thousands of direct tools and
greatly increases context usage. The server normally truncates large search and
execute results. Use `truncate:false` only when the full output will be handled
outside model context, such as direct file storage or code filtering.

Treat permission failures as reported failures, not evidence that the account is
empty. If OAuth actually requires renewal, use `codex mcp login cloudflare-api`
and preserve the user's full-scope preference. Keep stored OAuth credentials
private; do not read or print them for ordinary API tasks. A new CLI session may
be needed to expose newly registered MCP tools.

## Skills and references

The official server also publishes Cloudflare's product skills through the MCP
Skills extension (`skills/list`, `skill://<name>/<path>`) for supporting clients.
Do not assume every Codex client exposes that extension. This local skill makes
the workstation's integration guidance independently discoverable. It is locally
authored, not an official Cloudflare skill or a copy of its whole product bundle.

- Server usage/tool examples: https://github.com/cloudflare/mcp
- Official product skills: https://github.com/cloudflare/skills
- Official Codex setup: https://developers.cloudflare.com/agent-setup/codex/
- Dated local docs archive: `/home/nova/a1/cloudflare-docs/` (no Git history).

Use current official product docs for product-specific behavior, pricing and
limits. Load an appropriate official product skill when the task actually needs
development guidance; installing the entire catalog is unnecessary for API use.
