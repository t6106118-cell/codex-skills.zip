---
name: kitesurf
description: Use the installed Cloudflare KiteSurf remote browser through its MCP, Puppeteer CDP connection, or Browser Run Quick Actions. Use when the user requests KiteSurf, remote browser execution, or its Markdown, PDF, screenshot and extraction endpoints.
---

# KiteSurf on this workstation

KiteSurf is the remote browser engine. Codex MCP server `kitesurf` runs
`/home/nova/.local/bin/kitesurf-mcp`, a local Chrome DevTools MCP adapter.
Cloudflare Code Mode is a separate account API integration named `cloudflare-api`;
use its skill for account API tasks. BrowserOS/Surf hold the user's local browser
sessions; those sign-ins do not automatically transfer to KiteSurf.

## Choose the existing path

- Interactive browser work: discover the `kitesurf` MCP tools and use their live
  schemas. Their registration persists in `/home/nova/.codex/config.toml`.
  A newly added registration may require a fresh CLI session to expose tools.
- Browser scripts: import `connect` from
  `/home/nova/.local/opt/kitesurf/client.mjs` in a task-owned `.mjs` script.
  It returns a Puppeteer browser connected to remote KiteSurf. Close remote
  browsers created by the script when finished.
- Single-purpose output: `kitesurf-action ACTION REQUEST_JSON_FILE OUTPUT_FILE`.
  `-` reads JSON from stdin. Use an explicit output file for binary PDF/images.
  Actions include `markdown`, `pdf`, `screenshot`, `snapshot`, `links`, `scrape`,
  `json`, and `crawl`; read the current endpoint docs for the request schema.
  JSON/crawl were documented but were not exercised in the original local trial.
  Inspect returned JSON success/errors; HTTP success alone may not prove success.

Both local clients explicitly select `browser=kitesurf`. Reuse them rather than
rebuilding authentication. The private account/token file is
`/home/nova/.config/cloudflare/kitesurf.json`; never print or copy its contents
into prompts, skill files, command arguments or task artifacts.

## Form input and maintenance

The tested engine dropped keyboard newlines and failed `Input.insertText`.
The installed adapter uses Puppeteer's supported direct value assignment:
`locator.fill(text, { typingThreshold: 0 })`. This fixed the tested MCP form path,
including multiline Unicode values and actual submission. It emits synthetic
input/change events (`isTrusted=false`); it is not a native keyboard engine fix.

The adapter customization is maintained by
`/home/nova/.local/opt/kitesurf/patch-input.mjs` and its npm `postinstall` hook.
Preserve it when updating the local package. Do not replace this with per-key
typing to solve the same multiline failure. For applications requiring trusted
keyboard events, choose a suitable local browser instead.

Filtered links with visible/same-domain options returned an empty list in the
trial; default links returned relative URLs. Resolve relative URLs against the
source page when needed. This observation does not establish behavior for all sites.

## References

- Local results and exact usage: `/home/nova/a1/kitesurf-test/RESULTS.md`.
- Engine: https://developers.cloudflare.com/browser-run/kitesurf/
- CDP/MCP: https://developers.cloudflare.com/browser-run/cdp/mcp-clients/
- Endpoint schemas: https://developers.cloudflare.com/browser-run/quick-actions/
- Input option: https://pptr.dev/api/puppeteer.locatorfilloptions

Check current docs before relying on limits, supported browser features or beta
availability. The user's zero-budget requirement remains in force; do not activate
billing or paid plans. Broad workstation authorization covers routine tool use.
