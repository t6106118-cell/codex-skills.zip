# Install the integration skills on Fedora 43

Install these skills as the account that runs Codex on the server. From the
directory containing the ZIP, run:

```bash
(
    set -e
    skill_stage=$(mktemp -d)
    trap 'rm -rf -- "$skill_stage"' EXIT
    unzip -q agents-skills-fedora43-server.zip -d "$skill_stage"
    mkdir -p "$HOME/.agents/skills"
    cp -a "$skill_stage/skills/." "$HOME/.agents/skills/"
)
```

If these skill folders already exist with local edits, reconcile the changes
before copying. Start a fresh Codex CLI session after installation.

| Skill | Connection or runtime |
| --- | --- |
| browseros-neo | Connect Codex to a reachable BrowserOS Neo instance. |
| cloudflare-api | Connect the Cloudflare plugin or authenticate the Cloudflare Code Mode MCP server. |
| kitesurf | Install the KiteSurf adapter and configure its Cloudflare Browser Run credentials on the server. |

The archive contains only the integration skill folders and this guide.
Use the server's home directory and installed tool paths when interpreting
workstation-specific examples. Configure credentials on the server.
